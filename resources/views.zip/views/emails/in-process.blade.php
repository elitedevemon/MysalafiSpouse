{{-- <b>In-process</b>
<p>Your proposal has been in-process against {{ $data['profile_code'] }}</p>

<b>In-Process</b><br>
<a href="{{ url('/profile-view/') }}/{{ $data['id'] }}">{{ url('/profile-view') }}/{{ $data['id'] }}</a> --}}
{{ $data['profile_code'] }} is currently considering your profile. We will update you as soon as our team have a response from their side on the result of your match request.
</br>
<a href="{{ url('/profile-view/') }}/{{ $data['id'] }}">{{ url('/profile-view') }}/{{ $data['id'] }}</a>
</br>
BarakAllāhu Feekum, MySalafiSpouse team.