{{-- <p>Welcome</p> --}}
{{-- <p>Profile Update</p> --}}
<p><b>Your profile has been reject and your balance is reverted</b></p>
