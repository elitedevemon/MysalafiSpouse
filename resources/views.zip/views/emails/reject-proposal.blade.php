{{-- <b>Reject</b>

<p>{{ $data['receiver_profile_code'] }}  has been rejected proposal against {{ $data['sender_profile_code'] }}</p>

<b>Profile View</b><br>
<a href="{{ url('/profile-view/') }}/{{ $data['id'] }}">{{ url('/profile-view') }}/{{ $data['id'] }}</a> --}}
Your Match Request has been unsuccessful.
</br>
</br>
BarakAllāhu Feekum, MySalafiSpouse team.