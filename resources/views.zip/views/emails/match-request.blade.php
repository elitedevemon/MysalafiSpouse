{{-- Your Match Request has been sent. Please check your Match Request Updates page on the portal / your email inbox for
further updates regarding this Match Request.
<br><br>
BarakAllāhu Feekum,<br>
MySalafiSpouse team --}}
Your match request is currently processing - Please check your Match Request Updates page on the portal/your email inbox
for further updates regarding this Match Request.
We will get back to you with an update on the result of your match request to profile {{ $receiver }}.
<br>
BarakAllāhu Feekum,
MySalafiSpouse team
