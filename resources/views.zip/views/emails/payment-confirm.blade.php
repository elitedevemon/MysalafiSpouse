We can confirm we have received your fee payment.
<br>
BarakAllāhu Feekum,  MySalafiSpouse team.
