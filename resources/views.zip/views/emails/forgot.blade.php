{{-- <p>Welcome</p> --}}
<p>Your reset otp code is</p>

<p><b>OTP:</b> {{ $data['otp'] }}</p>