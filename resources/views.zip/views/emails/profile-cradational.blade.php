<p>Welcome</p>
<p>Your profile cradational</p>
<p><b>Email:</b> {{ $data['email'] }}</p>
<p><b>Password:</b> {{ $data['password'] }}</p>