{{-- 

<p>{{ $data['receiver_profile_code'] }}  has been shared guardian information with you</p>

<b>Profile View</b><br>
<a href="{{ url('/profile-view/') }}/{{ $data['id'] }}">{{ url('/profile-view') }}/{{ $data['id'] }}</a> --}}
{{ $data['receiver_profile_code'] }} Your Match Request has been successful! 
<br> {{ $data['receiver_profile_code'] }} Wali's contact details:  
<br> {{ $data['guardian'] }}   
<br>
Please do let us know how everything goes brother! <br><br>
BarakAllāhu Feekum, <br><br> MySalafiSpouse team.