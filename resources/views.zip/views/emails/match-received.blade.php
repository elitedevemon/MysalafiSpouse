<!-- <p>Welcome</p>
<p>Match Received</p>

<p><b>{{ $data['data'] }}</b> has sent request for match <b></b></p>asasdad

<b>Profile View</b><br>
<a href="{{ url('/profile-view/') }}/{{ $data['id'] }}">{{ url('/profile-view') }}/{{ $data['id'] }}</a> -->
Profile {{ $data['data'] }} is interested in your profile. Please see attached {{ $data['asasdad'] }} profile and kindly accept/reject the match request.
<br>
<a href="{{ url('/profile-view/') }}/{{ $data['id'] }}">{{ url('/profile-view') }}/{{ $data['id'] }}</a> 