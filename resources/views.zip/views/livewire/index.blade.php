<section id="content" class="full-width">
    <div id="post-11" class="post-11 page type-page status-publish hentry">
        <div class="post-content">
            <div class="fusion-fullwidth fullwidth-box fusion-builder-row-3 fusion-flex-container nonhundred-percent-fullwidth non-hundred-percent-height-scrolling"
                style="background-color: #224794;background-image:linear-gradient(180deg, rgba(2,66,125,0.02) 0%,rgba(2,29,124,0) 100%);background-position: center center;background-repeat: no-repeat;border-width: 0px 0px 0px 0px;border-color:rgba(0,0,0,0.08);border-style:solid;">
                <div class="fusion-builder-row fusion-row fusion-flex-align-items-flex-start"
                    style="max-width:1372.8px;margin-left: calc(-4% / 2 );margin-right: calc(-4% / 2 );">
                    <div
                        class="fusion-layout-column fusion_builder_column fusion-builder-column-7 fusion_builder_column_1_1 1_1 fusion-flex-column">
                        <div class="fusion-column-wrapper fusion-flex-justify-content-flex-start fusion-content-layout-column"
                            style="background-position:left top;background-repeat:no-repeat;-webkit-background-size:cover;-moz-background-size:cover;-o-background-size:cover;background-size:cover;padding: 0px 0px 0px 0px;">
                            <style type="text/css">
                                @media only screen and (max-width:1024px) {
                                    .fusion-title.fusion-title-1 {
                                        margin-top: 12px !important;
                                        margin-bottom: 24px !important;
                                    }
                                }
                                @media only screen and (max-width:640px) {
                                    .fusion-title.fusion-title-1 {
                                        margin-top: 12px !important;
                                        margin-bottom: 24px !important;
                                    }
                                }
                            </style>
                            <div class="fusion-title title fusion-title-1 fusion-sep-none fusion-title-center fusion-title-text fusion-title-size-one"
                                style="font-size:50px;margin-top:12px;margin-bottom:24px;">
                                <h1 class="title-heading-center"
                                    style="font-family:&quot;Poppins&quot;;font-weight:500;margin:0;font-size:1em;color:#ffffff;">
                                    250+ Matches Made So Far!</h1>
                            </div>
                            <div class="fusion-text fusion-text-1">
                                <p style="text-align: center;"><span style="color: #ffffff;">MATCHMAKING ACCORDING TO
                                        THE
                                        SUNNAH</span></p>
                            </div>
                        </div>
                    </div>
                    <style type="text/css">
                        .fusion-body .fusion-builder-column-7 {
                            width: 100% !important;
                            margin-top: 20px;
                            margin-bottom: 20px;
                        }
                        .fusion-builder-column-7>.fusion-column-wrapper {
                            padding-top: 0px !important;
                            padding-right: 0px !important;
                            margin-right: 1.92%;
                            padding-bottom: 0px !important;
                            padding-left: 0px !important;
                            margin-left: 1.92%;
                        }
                        @media only screen and (max-width:1024px) {
                            .fusion-body .fusion-builder-column-7 {
                                width: 100% !important;
                                order: 0;
                            }

                            .fusion-builder-column-7>.fusion-column-wrapper {
                                margin-right: 1.92%;
                                margin-left: 1.92%;
                            }
                        }

                        @media only screen and (max-width:640px) {
                            .fusion-body .fusion-builder-column-7 {
                                width: 100% !important;
                                order: 0;
                            }

                            .fusion-builder-column-7>.fusion-column-wrapper {
                                margin-right: 1.92%;
                                margin-left: 1.92%;
                            }
                        }

                    </style>
                    <div
                        class="fusion-layout-column fusion_builder_column fusion-builder-column-8 fusion_builder_column_1_3 1_3 fusion-flex-column">
                        <div class="fusion-column-wrapper fusion-flex-justify-content-flex-start fusion-content-layout-column"
                            style="background-position:left top;background-repeat:no-repeat;-webkit-background-size:cover;-moz-background-size:cover;-o-background-size:cover;background-size:cover;border-radius:5px 5px 5px 5px;background-color:#ffffff;border-radius:5px 5px 5px 5px;overflow:hidden;padding: 40px 30px 50px 30px;">
                            <div style="text-align:center;"><span
                                    class=" fusion-imageframe imageframe-none imageframe-3 hover-type-none"
                                    style="border-radius:8px;width:100%;max-width:150px;margin-top:40px;margin-right:10px;margin-bottom:10px;margin-left:10px;"><img
                                        width="1796" height="1798"
                                        src="{{ url('/site/images') }}/Screenshot-2020-12-12-at-22.30.34.png"
                                        class="lazyload img-responsive wp-image-3427" data-sizes="auto" /></span>
                            </div>
                            <div class="fusion-builder-row fusion-builder-row-inner fusion-row fusion-flex-align-items-flex-start"
                                style="width:104% !important;max-width:104% !important;margin-left: calc(-4% / 2 );margin-right: calc(-4% / 2 );">
                                <div
                                    class="fusion-layout-column fusion_builder_column_inner fusion-builder-nested-column-0 fusion_builder_column_inner_1_1 1_1 fusion-flex-column">
                                    <div class="fusion-column-wrapper fusion-flex-justify-content-flex-start fusion-content-layout-column"
                                        style="background-position:left top;background-repeat:no-repeat;-webkit-background-size:cover;-moz-background-size:cover;-o-background-size:cover;background-size:cover;padding: 0px 0px 0px 10px;">
                                        <style type="text/css">
                                            @media only screen and (max-width:1024px) {
                                                .fusion-title.fusion-title-2 {
                                                    margin-top: 5px !important;
                                                    margin-bottom: 5px !important;
                                                }
                                            }

                                            @media only screen and (max-width:640px) {
                                                .fusion-title.fusion-title-2 {
                                                    margin-top: 12px !important;
                                                    margin-bottom: 24px !important;
                                                }
                                            }

                                        </style>
                                        <div class="fusion-title title fusion-title-2 fusion-sep-none fusion-title-center fusion-title-text fusion-title-size-one"
                                            style="font-size:20px;margin-top:5px;margin-bottom:5px;">
                                            <h1 class="title-heading-center" style="margin:0;font-size:1em;">Step 1:
                                                Sign Up!
                                            </h1>
                                        </div>
                                        <div class="fusion-text fusion-text-2"
                                            style="text-align:center;font-size:15px;">
                                            <div
                                                class="fusion-title title fusion-title-3 fusion-sep-none fusion-title-center fusion-title-text fusion-title-size-one">
                                                <p class="title-heading-center fusion-responsive-typography-calculated"
                                                    data-fontsize="20" data-lineheight="22px"><span
                                                        style="font-size: 16px;">Sign up and our
                                                        team will pick up your application. All male
                                                        applicants are dealt with by a brother. All
                                                        female applicants are dealt with by a
                                                        sister. We’ll create a unique profile
                                                        tailored to you!</span></p>
                                            </div>
                                        </div>
                                        <div style="text-align:center;">
                                            <style type="text/css">
                                                .fusion-button.button-1 .fusion-button-text,
                                                .fusion-button.button-1 i {
                                                    color: #ffffff;
                                                }

                                                .fusion-button.button-1 .fusion-button-icon-divider {
                                                    border-color: #ffffff;
                                                }

                                                .fusion-button.button-1:hover .fusion-button-text,
                                                .fusion-button.button-1:hover i,
                                                .fusion-button.button-1:focus .fusion-button-text,
                                                .fusion-button.button-1:focus i,
                                                .fusion-button.button-1:active .fusion-button-text,
                                                .fusion-button.button-1:active {
                                                    color: #ffffff;
                                                }

                                                .fusion-button.button-1:hover .fusion-button-icon-divider,
                                                .fusion-button.button-1:hover .fusion-button-icon-divider,
                                                .fusion-button.button-1:active .fusion-button-icon-divider {
                                                    border-color: #ffffff;
                                                }

                                                .fusion-button.button-1:hover,
                                                .fusion-button.button-1:focus,
                                                .fusion-button.button-1:active {
                                                    border-color: #ffffff;
                                                }

                                                .fusion-button.button-1 {
                                                    border-color: #ffffff;
                                                    border-radius: 26px;
                                                }

                                                .fusion-button.button-1 {
                                                    background: #02427d;
                                                }

                                                .fusion-button.button-1:hover,
                                                .button-1:focus,
                                                .fusion-button.button-1:active {
                                                    background: #000000;
                                                }

                                            </style><a
                                                class="fusion-button button-flat button-medium button-custom button-1 fusion-button-default-span fusion-button-default-type"
                                                target="_self" href="{{ url('/want-to-signup') }}"><span class="fusion-button-text">I WANT TO SIGN
                                                    UP!</span></a>
                                        </div>
                                    </div>
                                </div>
                                <style type="text/css">
                                    .fusion-body .fusion-builder-nested-column-0 {
                                        width: 100% !important;
                                        margin-top: 20px;
                                        margin-bottom: 20px;
                                    }

                                    .fusion-builder-nested-column-0>.fusion-column-wrapper {
                                        padding-top: 0px !important;
                                        padding-right: 0px !important;
                                        margin-right: 1.824%;
                                        padding-bottom: 0px !important;
                                        padding-left: 10px !important;
                                        margin-left: 1.92%;
                                    }

                                    @media only screen and (max-width:1024px) {
                                        .fusion-body .fusion-builder-nested-column-0 {
                                            width: 100% !important;
                                            order: 0;
                                        }

                                        .fusion-builder-nested-column-0>.fusion-column-wrapper {
                                            margin-right: 1.824%;
                                            margin-left: 1.92%;
                                        }
                                    }

                                    @media only screen and (max-width:640px) {
                                        .fusion-body .fusion-builder-nested-column-0 {
                                            width: 100% !important;
                                            order: 0;
                                        }

                                        .fusion-builder-nested-column-0>.fusion-column-wrapper {
                                            margin-right: 1.92%;
                                            margin-left: 1.92%;
                                        }
                                    }

                                </style>
                            </div>
                        </div>
                    </div>
                    <style type="text/css">
                        .fusion-body .fusion-builder-column-8 {
                            width: 33.333333333333% !important;
                            margin-top: 20px;
                            margin-bottom: 20px;
                        }

                        .fusion-builder-column-8>.fusion-column-wrapper {
                            padding-top: 40 !important;
                            padding-right: 30 !important;
                            margin-right: 5.76%;
                            padding-bottom: 50 !important;
                            padding-left: 30 !important;
                            margin-left: 5.76%;
                        }

                        @media only screen and (max-width:1024px) {
                            .fusion-body .fusion-builder-column-8 {
                                width: 33.333333333333% !important;
                                order: 0;
                            }

                            .fusion-builder-column-8>.fusion-column-wrapper {
                                margin-right: 5.76%;
                                margin-left: 5.76%;
                            }
                        }

                        @media only screen and (max-width:640px) {
                            .fusion-body .fusion-builder-column-8 {
                                width: 100% !important;
                                order: 0;
                            }

                            .fusion-builder-column-8>.fusion-column-wrapper {
                                margin-right: 1.92%;
                                margin-left: 1.92%;
                            }
                        }

                    </style>
                    <div
                        class="fusion-layout-column fusion_builder_column fusion-builder-column-9 fusion_builder_column_1_3 1_3 fusion-flex-column">
                        <div class="fusion-column-wrapper fusion-flex-justify-content-flex-start fusion-content-layout-column"
                            style="background-position:left top;background-repeat:no-repeat;-webkit-background-size:cover;-moz-background-size:cover;-o-background-size:cover;background-size:cover;border-radius:5px 5px 5px 5px;background-color:#ffffff;border-radius:5px 5px 5px 5px;overflow:hidden;padding: 50px 30px 41px 30px;">
                            <div style="text-align:center;"><span
                                    class=" fusion-imageframe imageframe-none imageframe-4 hover-type-none"
                                    style="border-radius:8px;width:100%;max-width:150px;margin-top:40px;margin-right:10px;margin-bottom:10px;margin-left:10px;"><img
                                        width="1796" height="1798" title="Screenshot 2020-12-12 at 22.30.50"
                                        src="{{ url('site/images') }}/Screenshot-2020-12-12-at-22.30.50.png"
                                        data-sizes="auto" data-orig-sizes="(max-width: 640px) 100vw, 400px" /></span>
                            </div>
                            <div class="fusion-builder-row fusion-builder-row-inner fusion-row fusion-flex-align-items-flex-start"
                                style="width:104% !important;max-width:104% !important;margin-left: calc(-4% / 2 );margin-right: calc(-4% / 2 );">
                                <div
                                    class="fusion-layout-column fusion_builder_column_inner fusion-builder-nested-column-1 fusion_builder_column_inner_1_1 1_1 fusion-flex-column">
                                    <div class="fusion-column-wrapper fusion-flex-justify-content-flex-start fusion-content-layout-column"
                                        style="background-position:left top;background-repeat:no-repeat;-webkit-background-size:cover;-moz-background-size:cover;-o-background-size:cover;background-size:cover;padding: 0px 0px 0px 10px;">
                                        <style type="text/css">
                                            @media only screen and (max-width:1024px) {
                                                .fusion-title.fusion-title-3 {
                                                    margin-top: 5px !important;
                                                    margin-bottom: 5px !important;
                                                }
                                            }

                                            @media only screen and (max-width:640px) {
                                                .fusion-title.fusion-title-3 {
                                                    margin-top: 12px !important;
                                                    margin-bottom: 24px !important;
                                                }
                                            }

                                        </style>
                                        <div class="fusion-title title fusion-title-3 fusion-sep-none fusion-title-center fusion-title-text fusion-title-size-one"
                                            style="font-size:20px;margin-top:5px;margin-bottom:5px;">
                                            <h1 class="title-heading-center" style="margin:0;font-size:1em;">Step 2: The
                                                Matchmaking!</h1>
                                        </div>
                                        <div class="fusion-text fusion-text-3"
                                            style="text-align:center;font-size:15px;">
                                            <div
                                                class="fusion-title title fusion-title-4 fusion-sep-none fusion-title-center fusion-title-text fusion-title-size-one">
                                                <p class="title-heading-center fusion-responsive-typography-calculated"
                                                    data-fontsize="20" data-lineheight="22px"><span
                                                        style="font-size: 16px;">Match request with
                                                        the profiles on our database that you are
                                                        interested in. We’ll also recommend you to
                                                        match request with any profiles that we
                                                        think are compatible with you!</span></p>
                                            </div>
                                        </div>
                                        <div style="text-align:center;">
                                            <style type="text/css">
                                                .fusion-button.button-2 .fusion-button-text,
                                                .fusion-button.button-2 i {
                                                    color: #ffffff;
                                                }

                                                .fusion-button.button-2 .fusion-button-icon-divider {
                                                    border-color: #ffffff;
                                                }

                                                .fusion-button.button-2:hover .fusion-button-text,
                                                .fusion-button.button-2:hover i,
                                                .fusion-button.button-2:focus .fusion-button-text,
                                                .fusion-button.button-2:focus i,
                                                .fusion-button.button-2:active .fusion-button-text,
                                                .fusion-button.button-2:active {
                                                    color: #ffffff;
                                                }

                                                .fusion-button.button-2:hover .fusion-button-icon-divider,
                                                .fusion-button.button-2:hover .fusion-button-icon-divider,
                                                .fusion-button.button-2:active .fusion-button-icon-divider {
                                                    border-color: #ffffff;
                                                }

                                                .fusion-button.button-2:hover,
                                                .fusion-button.button-2:focus,
                                                .fusion-button.button-2:active {
                                                    border-color: #ffffff;
                                                }

                                                .fusion-button.button-2 {
                                                    border-color: #ffffff;
                                                    border-radius: 26px;
                                                }

                                                .fusion-button.button-2 {
                                                    background: #02427d;
                                                }

                                                .fusion-button.button-2:hover,
                                                .button-2:focus,
                                                .fusion-button.button-2:active {
                                                    background: #000000;
                                                }

                                            </style><a
                                                class="fusion-button button-flat button-medium button-custom button-2 fusion-button-default-span fusion-button-default-type"
                                                target="_self" href="{{ url('/want-to-signup') }}"><span class="fusion-button-text">I WANT TO SIGN
                                                    UP!</span></a>
                                        </div>
                                    </div>
                                </div>
                                <style type="text/css">
                                    .fusion-body .fusion-builder-nested-column-1 {
                                        width: 100% !important;
                                        margin-top: 20px;
                                        margin-bottom: 20px;
                                    }

                                    .fusion-builder-nested-column-1>.fusion-column-wrapper {
                                        padding-top: 0px !important;
                                        padding-right: 0px !important;
                                        margin-right: 0%;
                                        padding-bottom: 0px !important;
                                        padding-left: 10px !important;
                                        margin-left: 1.92%;
                                    }

                                    @media only screen and (max-width:1024px) {
                                        .fusion-body .fusion-builder-nested-column-1 {
                                            width: 100% !important;
                                            order: 0;
                                        }

                                        .fusion-builder-nested-column-1>.fusion-column-wrapper {
                                            margin-right: 0%;
                                            margin-left: 1.92%;
                                        }
                                    }

                                    @media only screen and (max-width:640px) {
                                        .fusion-body .fusion-builder-nested-column-1 {
                                            width: 100% !important;
                                            order: 0;
                                        }

                                        .fusion-builder-nested-column-1>.fusion-column-wrapper {
                                            margin-right: 1.92%;
                                            margin-left: 1.92%;
                                        }
                                    }

                                </style>
                            </div>
                        </div>
                    </div>
                    <style type="text/css">
                        .fusion-body .fusion-builder-column-9 {
                            width: 33.333333333333% !important;
                            margin-top: 20px;
                            margin-bottom: 20px;
                        }

                        .fusion-builder-column-9>.fusion-column-wrapper {
                            padding-top: 50 !important;
                            padding-right: 30 !important;
                            margin-right: 5.76%;
                            padding-bottom: 41px !important;
                            padding-left: 30 !important;
                            margin-left: 5.76%;
                        }

                        @media only screen and (max-width:1024px) {
                            .fusion-body .fusion-builder-column-9 {
                                width: 33.333333333333% !important;
                                order: 0;
                            }

                            .fusion-builder-column-9>.fusion-column-wrapper {
                                margin-right: 5.76%;
                                margin-left: 5.76%;
                            }
                        }

                        @media only screen and (max-width:640px) {
                            .fusion-body .fusion-builder-column-9 {
                                width: 100% !important;
                                order: 0;
                            }

                            .fusion-builder-column-9>.fusion-column-wrapper {
                                margin-right: 1.92%;
                                margin-left: 1.92%;
                            }
                        }

                    </style>
                    <div
                        class="fusion-layout-column fusion_builder_column fusion-builder-column-10 fusion_builder_column_1_3 1_3 fusion-flex-column">
                        <div class="fusion-column-wrapper fusion-flex-justify-content-flex-start fusion-content-layout-column"
                            style="background-position:left top;background-repeat:no-repeat;-webkit-background-size:cover;-moz-background-size:cover;-o-background-size:cover;background-size:cover;border-radius:5px 5px 5px 5px;background-color:#ffffff;border-radius:5px 5px 5px 5px;overflow:hidden;padding: 80px 30px 40px 30px;">
                            <div style="text-align:center;"><span
                                    class=" fusion-imageframe imageframe-none imageframe-5 hover-type-none"
                                    style="border-radius:8px;width:100%;max-width:150px;margin-top:40px;margin-right:10px;margin-bottom:10px;margin-left:10px;"><img
                                        width="227" height="106" title="23" src="{{ url('/site/images') }}/23-1.png"
                                        class="lazyload img-responsive wp-image-3393" data-sizes="auto"
                                        data-orig-sizes="(max-width: 640px) 100vw, 227px" /></span>
                            </div>
                            <div class="fusion-builder-row fusion-builder-row-inner fusion-row fusion-flex-align-items-flex-start"
                                style="width:104% !important;max-width:104% !important;margin-left: calc(-4% / 2 );margin-right: calc(-4% / 2 );">
                                <div
                                    class="fusion-layout-column fusion_builder_column_inner fusion-builder-nested-column-2 fusion_builder_column_inner_1_1 1_1 fusion-flex-column">
                                    <div class="fusion-column-wrapper fusion-flex-justify-content-flex-start fusion-content-layout-column"
                                        style="background-position:left top;background-repeat:no-repeat;-webkit-background-size:cover;-moz-background-size:cover;-o-background-size:cover;background-size:cover;padding: 0px 10px 0px 0px;">
                                        <style type="text/css">
                                            @media only screen and (max-width:1024px) {
                                                .fusion-title.fusion-title-4 {
                                                    margin-top: 5px !important;
                                                    margin-bottom: 5px !important;
                                                }
                                            }

                                            @media only screen and (max-width:640px) {
                                                .fusion-title.fusion-title-4 {
                                                    margin-top: 12px !important;
                                                    margin-bottom: 24px !important;
                                                }
                                            }

                                        </style>
                                        <div class="fusion-title title fusion-title-4 fusion-sep-none fusion-title-center fusion-title-text fusion-title-size-one"
                                            style="font-size:20px;margin-top:5px;margin-bottom:5px;">
                                            <h1 class="title-heading-center" style="margin:0;font-size:1em;">Step 3: The
                                                Marriage
                                                Meeting!</h1>
                                        </div>
                                        <div class="fusion-text fusion-text-4"
                                            style="text-align:center;font-size:15px;">
                                            <div
                                                class="fusion-title title fusion-title-5 fusion-sep-none fusion-title-center fusion-title-text fusion-title-size-one">
                                                <p class="title-heading-center fusion-responsive-typography-calculated"
                                                    data-fontsize="20" data-lineheight="22px"><span
                                                        style="font-size: 16px;">Once </span><span
                                                        style="font-size: 16px; color: var(--body_typography-color); font-family: var(--body_typography-font-family); font-style: var(--body_typography-font-style,normal); letter-spacing: var(--body_typography-letter-spacing);">matched,
                                                        we’ll help you by setting up a marriage
                                                        meeting with your potential spouse. Sisters
                                                        must provide us with their Wali’s contact
                                                        info and we will send that directly to the
                                                        brother. </span><span
                                                        style="color: var(--body_typography-color); font-family: var(--body_typography-font-family); font-size: 16px; font-style: var(--body_typography-font-style,normal); letter-spacing: var(--body_typography-letter-spacing);">Thereafter,
                                                        he can contact her Wali directly to arrange
                                                        a meeting.</span></p>
                                            </div>
                                        </div>
                                        <div style="text-align:center;">
                                            <style type="text/css">
                                                .fusion-button.button-3 .fusion-button-text,
                                                .fusion-button.button-3 i {
                                                    color: #ffffff;
                                                }

                                                .fusion-button.button-3 .fusion-button-icon-divider {
                                                    border-color: #ffffff;
                                                }

                                                .fusion-button.button-3:hover .fusion-button-text,
                                                .fusion-button.button-3:hover i,
                                                .fusion-button.button-3:focus .fusion-button-text,
                                                .fusion-button.button-3:focus i,
                                                .fusion-button.button-3:active .fusion-button-text,
                                                .fusion-button.button-3:active {
                                                    color: #ffffff;
                                                }

                                                .fusion-button.button-3:hover .fusion-button-icon-divider,
                                                .fusion-button.button-3:hover .fusion-button-icon-divider,
                                                .fusion-button.button-3:active .fusion-button-icon-divider {
                                                    border-color: #ffffff;
                                                }

                                                .fusion-button.button-3:hover,
                                                .fusion-button.button-3:focus,
                                                .fusion-button.button-3:active {
                                                    border-color: #ffffff;
                                                }

                                                .fusion-button.button-3 {
                                                    border-color: #ffffff;
                                                    border-radius: 26px;
                                                }

                                                .fusion-button.button-3 {
                                                    background: #02427d;
                                                }

                                                .fusion-button.button-3:hover,
                                                .button-3:focus,
                                                .fusion-button.button-3:active {
                                                    background: #000000;
                                                }

                                            </style><a
                                                class="fusion-button button-flat button-medium button-custom button-3 fusion-button-default-span fusion-button-default-type"
                                                target="_self" href="{{ url('/want-to-signup') }}"><span class="fusion-button-text">I WANT TO SIGN
                                                    UP!</span></a>
                                        </div>
                                    </div>
                                </div>
                                <style type="text/css">
                                    .fusion-body .fusion-builder-nested-column-2 {
                                        width: 100% !important;
                                        margin-top: 20px;
                                        margin-bottom: 20px;
                                    }

                                    .fusion-builder-nested-column-2>.fusion-column-wrapper {
                                        padding-top: 0px !important;
                                        padding-right: 10px !important;
                                        margin-right: 0%;
                                        padding-bottom: 0px !important;
                                        padding-left: 0px !important;
                                        margin-left: 3.552%;
                                    }

                                    @media only screen and (max-width:1024px) {
                                        .fusion-body .fusion-builder-nested-column-2 {
                                            width: 100% !important;
                                            order: 0;
                                        }

                                        .fusion-builder-nested-column-2>.fusion-column-wrapper {
                                            margin-right: 0%;
                                            margin-left: 3.552%;
                                        }
                                    }

                                    @media only screen and (max-width:640px) {
                                        .fusion-body .fusion-builder-nested-column-2 {
                                            width: 100% !important;
                                            order: 0;
                                        }

                                        .fusion-builder-nested-column-2>.fusion-column-wrapper {
                                            margin-right: 1.92%;
                                            margin-left: 1.92%;
                                        }
                                    }

                                </style>
                            </div>
                        </div>
                    </div>
                    <style type="text/css">
                        .fusion-body .fusion-builder-column-10 {
                            width: 33.333333333333% !important;
                            margin-top: 20px;
                            margin-bottom: 20px;
                        }

                        .fusion-builder-column-10>.fusion-column-wrapper {
                            padding-top: 80 !important;
                            padding-right: 30 !important;
                            margin-right: 5.76%;
                            padding-bottom: 40 !important;
                            padding-left: 30 !important;
                            margin-left: 5.76%;
                        }

                        @media only screen and (max-width:1024px) {
                            .fusion-body .fusion-builder-column-10 {
                                width: 33.333333333333% !important;
                                order: 0;
                            }

                            .fusion-builder-column-10>.fusion-column-wrapper {
                                margin-right: 5.76%;
                                margin-left: 5.76%;
                            }
                        }

                        @media only screen and (max-width:640px) {
                            .fusion-body .fusion-builder-column-10 {
                                width: 100% !important;
                                order: 0;
                            }

                            .fusion-builder-column-10>.fusion-column-wrapper {
                                margin-right: 1.92%;
                                margin-left: 1.92%;
                            }
                        }

                    </style>
                    <div
                        class="fusion-layout-column fusion_builder_column fusion-builder-column-11 fusion_builder_column_1_4 1_4 fusion-flex-column">
                        <div class="fusion-column-wrapper fusion-flex-justify-content-flex-start fusion-content-layout-column"
                            style="background-position:left top;background-repeat:no-repeat;-webkit-background-size:cover;-moz-background-size:cover;-o-background-size:cover;background-size:cover;padding: 0px 0px 0px 0px;">
                        </div>
                    </div>
                    <style type="text/css">
                        .fusion-body .fusion-builder-column-11 {
                            width: 25% !important;
                            margin-top: 20px;
                            margin-bottom: 20px;
                        }

                        .fusion-builder-column-11>.fusion-column-wrapper {
                            padding-top: 0px !important;
                            padding-right: 0px !important;
                            margin-right: 7.68%;
                            padding-bottom: 0px !important;
                            padding-left: 0px !important;
                            margin-left: 7.68%;
                        }

                        @media only screen and (max-width:1024px) {
                            .fusion-body .fusion-builder-column-11 {
                                width: 25% !important;
                                order: 0;
                            }

                            .fusion-builder-column-11>.fusion-column-wrapper {
                                margin-right: 7.68%;
                                margin-left: 7.68%;
                            }
                        }

                        @media only screen and (max-width:640px) {
                            .fusion-body .fusion-builder-column-11 {
                                width: 100% !important;
                                order: 0;
                            }

                            .fusion-builder-column-11>.fusion-column-wrapper {
                                margin-right: 1.92%;
                                margin-left: 1.92%;
                            }
                        }

                    </style>
                    <div
                        class="fusion-layout-column fusion_builder_column fusion-builder-column-12 fusion_builder_column_1_2 1_2 fusion-flex-column">
                        <div class="fusion-column-wrapper fusion-flex-justify-content-flex-start fusion-content-layout-column"
                            style="background-position:left top;background-repeat:no-repeat;-webkit-background-size:cover;-moz-background-size:cover;-o-background-size:cover;background-size:cover;padding: 0px 0px 0px 0px;">
                            <div style="text-align:center;">
                                <style type="text/css">
                                    .fusion-button.button-4 .fusion-button-text,
                                    .fusion-button.button-4 i {
                                        color: #000000;
                                    }

                                    .fusion-button.button-4 .fusion-button-icon-divider {
                                        border-color: #000000;
                                    }

                                    .fusion-button.button-4:hover .fusion-button-text,
                                    .fusion-button.button-4:hover i,
                                    .fusion-button.button-4:focus .fusion-button-text,
                                    .fusion-button.button-4:focus i,
                                    .fusion-button.button-4:active .fusion-button-text,
                                    .fusion-button.button-4:active {
                                        color: #ffffff;
                                    }

                                    .fusion-button.button-4:hover .fusion-button-icon-divider,
                                    .fusion-button.button-4:hover .fusion-button-icon-divider,
                                    .fusion-button.button-4:active .fusion-button-icon-divider {
                                        border-color: #ffffff;
                                    }

                                    .fusion-button.button-4:hover,
                                    .fusion-button.button-4:focus,
                                    .fusion-button.button-4:active {
                                        border-color: #ffffff;
                                    }

                                    .fusion-button.button-4 {
                                        border-color: #ffffff;
                                        border-radius: 5px;
                                    }

                                    .fusion-button.button-4 {
                                        background: #ffffff;
                                    }

                                    .fusion-button.button-4:hover,
                                    .button-4:focus,
                                    .fusion-button.button-4:active {
                                        background: #000000;
                                    }

                                </style><a
                                    class="fusion-button button-flat button-xlarge button-custom button-4 fusion-button-default-span "
                                    target="_self" href="{{ url('/want-to-signup') }}"><span class="fusion-button-text">I WANT TO SIGN
                                        UP!</span></a>
                            </div>
                        </div>
                    </div>
                    <style type="text/css">
                        .fusion-body .fusion-builder-column-12 {
                            width: 50% !important;
                            margin-top: 20px;
                            margin-bottom: 20px;
                        }

                        .fusion-builder-column-12>.fusion-column-wrapper {
                            padding-top: 0px !important;
                            padding-right: 0px !important;
                            margin-right: 3.84%;
                            padding-bottom: 0px !important;
                            padding-left: 0px !important;
                            margin-left: 3.84%;
                        }

                        @media only screen and (max-width:1024px) {
                            .fusion-body .fusion-builder-column-12 {
                                width: 50% !important;
                                order: 0;
                            }

                            .fusion-builder-column-12>.fusion-column-wrapper {
                                margin-right: 3.84%;
                                margin-left: 3.84%;
                            }
                        }

                        @media only screen and (max-width:640px) {
                            .fusion-body .fusion-builder-column-12 {
                                width: 100% !important;
                                order: 0;
                            }

                            .fusion-builder-column-12>.fusion-column-wrapper {
                                margin-right: 1.92%;
                                margin-left: 1.92%;
                            }
                        }

                    </style>
                    <div
                        class="fusion-layout-column fusion_builder_column fusion-builder-column-13 fusion_builder_column_1_4 1_4 fusion-flex-column">
                        <div class="fusion-column-wrapper fusion-flex-justify-content-flex-start fusion-content-layout-column"
                            style="background-position:left top;background-repeat:no-repeat;-webkit-background-size:cover;-moz-background-size:cover;-o-background-size:cover;background-size:cover;padding: 0px 0px 0px 0px;">
                        </div>
                    </div>
                    <style type="text/css">
                        .fusion-body .fusion-builder-column-13 {
                            width: 25% !important;
                            margin-top: 20px;
                            margin-bottom: 20px;
                        }

                        .fusion-builder-column-13>.fusion-column-wrapper {
                            padding-top: 0px !important;
                            padding-right: 0px !important;
                            margin-right: 7.68%;
                            padding-bottom: 0px !important;
                            padding-left: 0px !important;
                            margin-left: 7.68%;
                        }

                        @media only screen and (max-width:1024px) {
                            .fusion-body .fusion-builder-column-13 {
                                width: 25% !important;
                                order: 0;
                            }

                            .fusion-builder-column-13>.fusion-column-wrapper {
                                margin-right: 7.68%;
                                margin-left: 7.68%;
                            }
                        }

                        @media only screen and (max-width:640px) {
                            .fusion-body .fusion-builder-column-13 {
                                width: 100% !important;
                                order: 0;
                            }

                            .fusion-builder-column-13>.fusion-column-wrapper {
                                margin-right: 1.92%;
                                margin-left: 1.92%;
                            }
                        }

                    </style>
                </div>
                <style type="text/css">
                    .fusion-body .fusion-flex-container.fusion-builder-row-3 {
                        padding-top: 30px;
                        margin-top: 0px;
                        padding-right: 32px;
                        padding-bottom: 60px;
                        margin-bottom: 0px;
                        padding-left: 32px;
                    }

                </style>
            </div>
            <div class="fusion-fullwidth fullwidth-box fusion-builder-row-4 fusion-flex-container nonhundred-percent-fullwidth non-hundred-percent-height-scrolling"
                style="background-color: rgba(255,255,255,0);background-position: center center;background-repeat: no-repeat;border-width: 0px 0px 0px 0px;border-color:rgba(0,0,0,0.08);border-style:solid;">
                <div class="fusion-builder-row fusion-row fusion-flex-align-items-flex-start"
                    style="max-width:1372.8px;margin-left: calc(-4% / 2 );margin-right: calc(-4% / 2 );">
                    <div
                        class="fusion-layout-column fusion_builder_column fusion-builder-column-14 fusion_builder_column_1_2 1_2 fusion-flex-column fusion-flex-align-self-center">
                        <div class="fusion-column-wrapper fusion-flex-justify-content-center fusion-content-layout-column"
                            style="background-position:left top;background-repeat:no-repeat;-webkit-background-size:cover;-moz-background-size:cover;-o-background-size:cover;background-size:cover;padding: 0px 0px 0px 0px;">
                            <style type="text/css">
                                @media only screen and (max-width:1024px) {
                                    .fusion-title.fusion-title-5 {
                                        margin-top: 12px !important;
                                        margin-bottom: 24px !important;
                                    }
                                }

                                @media only screen and (max-width:640px) {
                                    .fusion-title.fusion-title-5 {
                                        margin-top: 12px !important;
                                        margin-bottom: 24px !important;
                                    }
                                }

                            </style>
                            <div class="fusion-title title fusion-title-5 fusion-sep-none fusion-title-text fusion-title-size-one"
                                style="font-size:30px;margin-top:12px;margin-bottom:24px;">
                                <h1 class="title-heading-left"
                                    style="font-family:&quot;Poppins&quot;;font-weight:500;margin:0;font-size:1em;color:#303030;">
                                    About Us</h1>
                            </div>
                            <div class="fusion-text fusion-text-5" style="line-height:1.8em;">
                                {{ $about->about_us }}
                            </div>
                        </div>
                    </div>
                    <style type="text/css">
                        .fusion-body .fusion-builder-column-14 {
                            width: 50% !important;
                            margin-top: 20px;
                            margin-bottom: 20px;
                        }

                        .fusion-builder-column-14>.fusion-column-wrapper {
                            padding-top: 0px !important;
                            padding-right: 0px !important;
                            margin-right: 3.84%;
                            padding-bottom: 0px !important;
                            padding-left: 0px !important;
                            margin-left: 3.84%;
                        }

                        @media only screen and (max-width:1024px) {
                            .fusion-body .fusion-builder-column-14 {
                                width: 50% !important;
                                order: 0;
                            }

                            .fusion-builder-column-14>.fusion-column-wrapper {
                                margin-right: 3.84%;
                                margin-left: 3.84%;
                            }
                        }

                        @media only screen and (max-width:640px) {
                            .fusion-body .fusion-builder-column-14 {
                                width: 100% !important;
                                order: 0;
                            }

                            .fusion-builder-column-14>.fusion-column-wrapper {
                                margin-right: 1.92%;
                                margin-left: 1.92%;
                            }
                        }

                    </style>
                    <div
                        class="fusion-layout-column fusion_builder_column fusion-builder-column-15 fusion_builder_column_1_2 1_2 fusion-flex-column">
                        <div class="fusion-column-wrapper fusion-flex-justify-content-flex-start fusion-content-layout-column"
                            style="background-position:left top;background-repeat:no-repeat;-webkit-background-size:cover;-moz-background-size:cover;-o-background-size:cover;background-size:cover;padding: 0px 0px 0px 0px;">
                            <div class="fusion-video fusion-youtube"
                                style="max-width:600px;max-height:360px;align-self:center; width:100%">
                                <div class="video-shortcode">

                                    <iframe title="YouTube video player" src="{{ $about->video_link }} " width="600"
                                        height="360" allowfullscreen allow="autoplay; fullscreen"></iframe>
                                </div>
                            </div>
                        </div>
                    </div>
                    <style type="text/css">
                        .fusion-body .fusion-builder-column-15 {
                            width: 50% !important;
                            margin-top: 100px;
                            margin-bottom: 20px;
                        }

                        .fusion-builder-column-15>.fusion-column-wrapper {
                            padding-top: 0px !important;
                            padding-right: 0px !important;
                            margin-right: 3.84%;
                            padding-bottom: 0px !important;
                            padding-left: 0px !important;
                            margin-left: 3.84%;
                        }

                        @media only screen and (max-width:1024px) {
                            .fusion-body .fusion-builder-column-15 {
                                width: 50% !important;
                                order: 0;
                            }

                            .fusion-builder-column-15>.fusion-column-wrapper {
                                margin-right: 3.84%;
                                margin-left: 3.84%;
                            }
                        }

                        @media only screen and (max-width:640px) {
                            .fusion-body .fusion-builder-column-15 {
                                width: 100% !important;
                                order: 0;
                            }

                            .fusion-builder-column-15>.fusion-column-wrapper {
                                margin-right: 1.92%;
                                margin-left: 1.92%;
                            }
                        }

                    </style>
                    <div
                        class="fusion-layout-column fusion_builder_column fusion-builder-column-16 fusion_builder_column_1_1 1_1 fusion-flex-column">
                        <div class="fusion-column-wrapper fusion-flex-justify-content-flex-start fusion-content-layout-column"
                            style="background-position:left top;background-repeat:no-repeat;-webkit-background-size:cover;-moz-background-size:cover;-o-background-size:cover;background-size:cover;padding: 0px 0px 0px 0px;">
                            <div class="fusion-text fusion-text-6">
                                <div class="eapps-testimonials-slider-header" eapps-link="title">
                                    <div class="eui-widget-title" style="display: block;padding:0px;">Reviews From Our
                                        Successful Applicants:</div>
                                </div>
                                <style>
                                    .card {
                                    position: relative;
                                    display: flex;
                                    width: 400px !important;
                                    flex-direction: column;
                                    min-width: 0;
                                    word-wrap: break-word;
                                    background-color: #fff;
                                    background-clip: border-box;
                                    border: 0px solid white;
                                    border-radius: 11px;
                                    -webkit-box-shadow: 0px 0px 5px 0px rgb(249, 249, 250);
                                    -moz-box-shadow: 0px 0px 5px 0px rgba(212, 182, 212, 1);
                                    box-shadow: 0px 0px 0px 0px rgb(161, 163, 164)
                                }           
                                </style>
                                <div class="items">
                                    @foreach($review as $item)
                                    <div class="card">
                                        <div class="card-body">
                                            <div style="width:20%; display:inline-block;">
                                            @if($item->type == 0)
                                            <img class="profile-pic" src="{{url('/bother.png')}}"></div>
                                            @else
                                            <img class="profile-pic" src="{{url('/sister.png')}}"></div>
                                            @endif
                                        <div style="width:70%; display:inline-block;">
                                            <b class="cust-name">{{ $item->name }}</b><br>
                                            <i style="color:#FFD700;" class="fa fa-star"></i>
                                            <i style="color:#FFD700;" class="fa fa-star"></i>
                                            <i style="color:#FFD700;" class="fa fa-star"></i>
                                            <i style="color:#FFD700;" class="fa fa-star"></i>
                                            <i style="color:#FFD700;" class="fa fa-star"></i>
                                        </div>
                                            <div class="template-demo">
                                                <br>
                                                <br>
                                                {{-- <p> --}}
                                                @if($fulltextshow)
                                                <p id="sometext{{ $item->id }}"> {{ Str::limit($item->text, 230) }}<br>
                                                </p>
                                                <a style="cursor: pointer" onclick="fulltext({{ $item }})">Read more</a>
                                                <br>
                                                <br>
                                                @endif
                                                {{-- </p> --}}
                                            </div>
                                            <hr>
                                            

                                        </div>
                                    </div>
                                    @endforeach
                                    <div wire:ignore.self>
                                        <script>
                                            function fulltext(item) {
                                                var data = item.text
                                                document.getElementById('sometext' + item.id).innerHTML = data;

                                            }
                                        </script>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                    <style type="text/css">
                        .fusion-body .fusion-builder-column-16 {
                            width: 100% !important;
                            margin-top: 50px;
                            margin-bottom: 50px;
                        }

                        .fusion-builder-column-16>.fusion-column-wrapper {
                            padding-top: 0px !important;
                            padding-right: 0px !important;
                            margin-right: 1.92%;
                            padding-bottom: 0px !important;
                            padding-left: 0px !important;
                            margin-left: 1.92%;
                        }

                        @media only screen and (max-width:1024px) {
                            .fusion-body .fusion-builder-column-16 {
                                width: 100% !important;
                                order: 0;
                            }

                            .fusion-builder-column-16>.fusion-column-wrapper {
                                margin-right: 1.92%;
                                margin-left: 1.92%;
                            }
                        }

                        @media only screen and (max-width:640px) {
                            .fusion-body .fusion-builder-column-16 {
                                width: 100% !important;
                                order: 0;
                            }

                            .fusion-builder-column-16>.fusion-column-wrapper {
                                margin-right: 1.92%;
                                margin-left: 1.92%;
                            }
                        }

                    </style>
                </div>
                <style type="text/css">
                    .fusion-body .fusion-flex-container.fusion-builder-row-4 {
                        padding-top: 50px;
                        margin-top: 0px;
                        padding-right: 32px;
                        padding-bottom: 40px;
                        margin-bottom: 0px;
                        padding-left: 32px;
                    }

                </style>
            </div>
            <div class="fusion-fullwidth fullwidth-box fusion-builder-row-5 fusion-flex-container nonhundred-percent-fullwidth non-hundred-percent-height-scrolling"
                style="background-color: rgba(255,255,255,0);background-position: center center;background-repeat: no-repeat;border-width: 0px 0px 0px 0px;border-color:rgba(0,0,0,0.08);border-style:solid;">
                <div class="fusion-builder-row fusion-row fusion-flex-align-items-flex-start"
                    style="max-width:1372.8px;margin-left: calc(-4% / 2 );margin-right: calc(-4% / 2 );">
                    <div
                        class="fusion-layout-column fusion_builder_column fusion-builder-column-17 fusion_builder_column_1_1 1_1 fusion-flex-column">
                        <div class="fusion-column-wrapper fusion-flex-justify-content-flex-start fusion-content-layout-column"
                            style="background-position:left top;background-repeat:no-repeat;-webkit-background-size:cover;-moz-background-size:cover;-o-background-size:cover;background-size:cover;padding: 0px 0px 0px 0px;">
                            <div style="text-align:center;"><span
                                    class=" fusion-imageframe imageframe-none imageframe-6 hover-type-none"
                                    style="border-radius:8px;"><a class="fusion-no-lightbox" href="{{ url('/want-to-signup') }}" target="_self"
                                        aria-label="Screenshot 2020-12-11 at 23.10.05"><img width="2396" height="1794"
                                            src="{{ url('/site/images') }}/Screenshot-2020-12-11-at-23.10.05.png"
                                            data-sizes="auto"
                                            data-orig-sizes="(max-width: 640px) 100vw, 2396px" /></a></span>
                            </div>
                        </div>
                    </div>
                    <style type="text/css">
                        .fusion-body .fusion-builder-column-17 {
                            width: 100% !important;
                            margin-top: 20px;
                            margin-bottom: 20px;
                        }

                        .fusion-builder-column-17>.fusion-column-wrapper {
                            padding-top: 0px !important;
                            padding-right: 0px !important;
                            margin-right: 1.92%;
                            padding-bottom: 0px !important;
                            padding-left: 0px !important;
                            margin-left: 1.92%;
                        }

                        @media only screen and (max-width:1024px) {
                            .fusion-body .fusion-builder-column-17 {
                                width: 100% !important;
                                order: 0;
                            }

                            .fusion-builder-column-17>.fusion-column-wrapper {
                                margin-right: 1.92%;
                                margin-left: 1.92%;
                            }
                        }

                        @media only screen and (max-width:640px) {
                            .fusion-body .fusion-builder-column-17 {
                                width: 100% !important;
                                order: 0;
                            }

                            .fusion-builder-column-17>.fusion-column-wrapper {
                                margin-right: 1.92%;
                                margin-left: 1.92%;
                            }
                        }

                    </style>
                </div>
                <style type="text/css">
                    .fusion-body .fusion-flex-container.fusion-builder-row-5 {
                        padding-top: 0px;
                        margin-top: 0px;
                        padding-right: 32px;
                        padding-bottom: 0px;
                        margin-bottom: 0px;
                        padding-left: 32px;
                    }

                </style>
            </div>
            <div class="fusion-fullwidth fullwidth-box fusion-builder-row-6 fusion-flex-container nonhundred-percent-fullwidth non-hundred-percent-height-scrolling"
                style="background-color: rgba(255,255,255,0);background-position: center center;background-repeat: no-repeat;border-width: 0px 0px 0px 0px;border-color:rgba(0,0,0,0.08);border-style:solid;">
                <div class="fusion-builder-row fusion-row fusion-flex-align-items-flex-start"
                    style="max-width:1372.8px;margin-left: calc(-4% / 2 );margin-right: calc(-4% / 2 );">
                    <div
                        class="fusion-layout-column fusion_builder_column fusion-builder-column-18 fusion_builder_column_1_1 1_1 fusion-flex-column">
                        <div class="fusion-column-wrapper fusion-flex-justify-content-flex-start fusion-content-layout-column"
                            style="background-position:left top;background-repeat:no-repeat;-webkit-background-size:cover;-moz-background-size:cover;-o-background-size:cover;background-size:cover;padding: 0px 0px 0px 0px;">
                            <style type="text/css">
                                @media only screen and (max-width:1024px) {
                                    .fusion-title.fusion-title-6 {
                                        margin-top: 12px !important;
                                        margin-bottom: 24px !important;
                                    }
                                }

                                @media only screen and (max-width:640px) {
                                    .fusion-title.fusion-title-6 {
                                        margin-top: 12px !important;
                                        margin-bottom: 24px !important;
                                    }
                                }

                            </style>
                            <div class="fusion-title title fusion-title-6 fusion-sep-none fusion-title-center fusion-title-text fusion-title-size-one"
                                style="font-size:30px;margin-top:12px;margin-bottom:24px;">
                                <h1 class="title-heading-center"
                                    style="font-family:&quot;Poppins&quot;;font-weight:500;margin:0;font-size:1em;color:#303030;">
                                    See Some Of Our Profiles!</h1>
                            </div>
                            <div class="fusion-text fusion-text-7" style="line-height:1.8em;">
                                <p style="text-align: center;">The MySalafiSpouse matchmaking
                                    service is designed for orthodox Muslims worldwide. Any Muslim
                                    who follows the Sunnah can apply!</p>
                            </div>
                            <div
                                class="fusion-layout-column fusion_builder_column fusion-builder-column-16 fusion_builder_column_1_1 1_1 fusion-flex-column">
                                <div class="fusion-column-wrapper fusion-flex-justify-content-flex-start fusion-content-layout-column"
                                    style="background-position:left top;background-repeat:no-repeat;-webkit-background-size:cover;-moz-background-size:cover;-o-background-size:cover;background-size:cover;padding: 0px 0px 0px 0px;">
                                    <div class="fusion-text fusion-text-6">
                                        <div class="eapps-testimonials-slider-header" eapps-link="title">
                                        </div>
                                        
                                        <div class="items">
                                            @foreach($post as $item)
                                            @foreach($item as $utem)
                                            <div class="card">
                                                <div class="card-body">
                                                   
                                                        @if(isset($utem['media_url']))
                                                        <a target="_blank" href="{{ $utem['permalink'] ?? '' }}" >
                                                        <img  src="{{ $utem['media_url']  }}" alt="{{ $utem['media_url'] ?? '' }}">
                                                        </a>
                                                        @endif
                                               
                                                </div>
                                            </div>
                                            @endforeach
                                            @endforeach
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <style type="text/css">
                        .fusion-body .fusion-builder-column-18 {
                            width: 100% !important;
                            margin-top: 20px;
                            margin-bottom: 20px;
                        }

                        .fusion-builder-column-18>.fusion-column-wrapper {
                            padding-top: 0px !important;
                            padding-right: 0px !important;
                            margin-right: 1.92%;
                            padding-bottom: 0px !important;
                            padding-left: 0px !important;
                            margin-left: 1.92%;
                        }

                        @media only screen and (max-width:1024px) {
                            .fusion-body .fusion-builder-column-18 {
                                width: 100% !important;
                                order: 0;
                            }

                            .fusion-builder-column-18>.fusion-column-wrapper {
                                margin-right: 1.92%;
                                margin-left: 1.92%;
                            }
                        }

                        @media only screen and (max-width:640px) {
                            .fusion-body .fusion-builder-column-18 {
                                width: 100% !important;
                                order: 0;
                            }

                            .fusion-builder-column-18>.fusion-column-wrapper {
                                margin-right: 1.92%;
                                margin-left: 1.92%;
                            }
                        }

                    </style>
                </div>
                <style type="text/css">
                    .fusion-body .fusion-flex-container.fusion-builder-row-6 {
                        padding-top: 0px;
                        margin-top: 0px;
                        padding-right: 32px;
                        padding-bottom: 0px;
                        margin-bottom: 0px;
                        padding-left: 32px;
                    }

                </style>
            </div>
            <div class="fusion-fullwidth fullwidth-box fusion-builder-row-7 fusion-flex-container nonhundred-percent-fullwidth non-hundred-percent-height-scrolling"
                style="background-color: rgba(255,255,255,0);background-position: center center;background-repeat: no-repeat;border-width: 0px 0px 0px 0px;border-color:rgba(0,0,0,0.08);border-style:solid;">
                <div class="fusion-builder-row fusion-row fusion-flex-align-items-flex-start"
                    style="max-width:1372.8px;margin-left: calc(-4% / 2 );margin-right: calc(-4% / 2 );">
                    <div
                        class="fusion-layout-column fusion_builder_column fusion-builder-column-19 fusion_builder_column_1_1 1_1 fusion-flex-column fusion-flex-align-self-center">
                        <div class="fusion-column-wrapper fusion-flex-justify-content-center fusion-content-layout-column"
                            style="background-position:left top;background-repeat:no-repeat;-webkit-background-size:cover;-moz-background-size:cover;-o-background-size:cover;background-size:cover;padding: 0px 0px 0px 0px;">
                            <style type="text/css">
                                @media only screen and (max-width:1024px) {
                                    .fusion-title.fusion-title-7 {
                                        margin-top: 12px !important;
                                        margin-bottom: 24px !important;
                                    }
                                }

                                @media only screen and (max-width:640px) {
                                    .fusion-title.fusion-title-7 {
                                        margin-top: 12px !important;
                                        margin-bottom: 24px !important;
                                    }
                                }

                            </style>
                            <div class="fusion-title title fusion-title-7 fusion-sep-none fusion-title-text fusion-title-size-one"
                                style="font-size:30px;margin-top:12px;margin-bottom:24px;">
                                <h1 class="title-heading-left"
                                    style="font-family:&quot;Poppins&quot;;font-weight:500;margin:0;font-size:1em;color:#303030;">
                                    <p style="text-align: center;">Contact Us:</p>
                                </h1>
                            </div>
                        </div>
                    </div>
                    <style type="text/css">
                        .fusion-body .fusion-builder-column-19 {
                            width: 100% !important;
                            margin-top: 20px;
                            margin-bottom: 20px;
                        }
                        .fusion-builder-column-19>.fusion-column-wrapper {
                            padding-top: 0px !important;
                            padding-right: 0px !important;
                            margin-right: 1.92%;
                            padding-bottom: 0px !important;
                            padding-left: 0px !important;
                            margin-left: 1.92%;
                        }

                        @media only screen and (max-width:1024px) {
                            .fusion-body .fusion-builder-column-19 {
                                width: 100% !important;
                                order: 0;
                            }
                            .fusion-builder-column-19>.fusion-column-wrapper {
                                margin-right: 1.92%;
                                margin-left: 1.92%;
                            }
                        }
                        @media only screen and (max-width:640px) {
                            .fusion-body .fusion-builder-column-19 {
                                width: 100% !important;
                                order: 0;
                            }
                            .fusion-builder-column-19>.fusion-column-wrapper {
                                margin-right: 1.92%;
                                margin-left: 1.92%;
                            }
                        }
                    </style>
                    <div
                        class="fusion-layout-column fusion_builder_column fusion-builder-column-20 fusion_builder_column_1_3 1_3 fusion-flex-column fusion-flex-align-self-center">
                        <div class="fusion-column-wrapper fusion-flex-justify-content-center fusion-content-layout-column"
                            style="background-position:left top;background-repeat:no-repeat;-webkit-background-size:cover;-moz-background-size:cover;-o-background-size:cover;background-size:cover;padding: 0px 0px 0px 0px;">
                            <ul class="fusion-checklist fusion-checklist-1" style="font-size:22px;line-height:37.4px;">
                                <li class="fusion-li-item"><span
                                        style="background-color:#ffffff;font-size:19.36px;height:37.4px;width:37.4px;margin-right:15.4px;"
                                        class="icon-wrapper circle-yes"><i class="fa fa-instagram" style="color:#000000;"
                                            aria-hidden="true"></i></span>
                                    <div class="fusion-li-item-content" style="margin-left:52.8px;">
                                        <p><a href="{{ $social->instagram }}">@mysalafispouse</a>
                                        </p>
                                    </div>
                                </li>
                                <li class="fusion-li-item"><span
                                        style="background-color:#ffffff;font-size:19.36px;height:37.4px;width:37.4px;margin-right:15.4px;"
                                        class="icon-wrapper circle-yes"><i class="fusion-li-icon fa-twitter fab"
                                            style="color:#000000;" aria-hidden="true"></i></span>
                                    <div class="fusion-li-item-content" style="margin-left:52.8px;">
                                        <p><a href="{{ $social->twiter }}">@mysalafispouse</a>
                                        </p>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <style type="text/css">
                        .fusion-body .fusion-builder-column-20 {
                            width: 33.333333333333% !important;
                            margin-top: 20px;
                            margin-bottom: 20px;
                        }
                        .fusion-builder-column-20>.fusion-column-wrapper {
                            padding-top: 0px !important;
                            padding-right: 0px !important;
                            margin-right: 5.76%;
                            padding-bottom: 0px !important;
                            padding-left: 0px !important;
                            margin-left: 5.76%;
                        }

                        @media only screen and (max-width:1024px) {
                            .fusion-body .fusion-builder-column-20 {
                                width: 33.333333333333% !important;
                                order: 0;
                            }

                            .fusion-builder-column-20>.fusion-column-wrapper {
                                margin-right: 5.76%;
                                margin-left: 5.76%;
                            }
                        }

                        @media only screen and (max-width:640px) {
                            .fusion-body .fusion-builder-column-20 {
                                width: 100% !important;
                                order: 0;
                            }

                            .fusion-builder-column-20>.fusion-column-wrapper {
                                margin-right: 1.92%;
                                margin-left: 1.92%;
                            }
                        }

                    </style>
                    <div
                        class="fusion-layout-column fusion_builder_column fusion-builder-column-21 fusion_builder_column_1_3 1_3 fusion-flex-column fusion-flex-align-self-center">
                        <div class="fusion-column-wrapper fusion-flex-justify-content-center fusion-content-layout-column"
                            style="background-position:left top;background-repeat:no-repeat;-webkit-background-size:cover;-moz-background-size:cover;-o-background-size:cover;background-size:cover;padding: 0px 0px 0px 0px;">
                            <ul class="fusion-checklist fusion-checklist-2" style="font-size:22px;line-height:37.4px;">
                                <li class="fusion-li-item"><span
                                        style="background-color:#ffffff;font-size:19.36px;height:37.4px;width:37.4px;margin-right:15.4px;"
                                        class="icon-wrapper circle-yes"><i class="fusion-li-icon fa-facebook-f fab"
                                            style="color:#000000;" aria-hidden="true"></i></span>
                                    <div class="fusion-li-item-content" style="margin-left:52.8px;">
                                        <p><a href="{{ $social->facebook }}">@mysalafispouse</a>
                                        </p>
                                    </div>
                                </li>
                                <li class="fusion-li-item"><span
                                        style="background-color:#ffffff;font-size:19.36px;height:37.4px;width:37.4px;margin-right:15.4px;"
                                        class="icon-wrapper circle-yes"><i class="fusion-li-icon fa-linkedin-in fab"
                                            style="color:#000000;" aria-hidden="true"></i></span>
                                    <div class="fusion-li-item-content" style="margin-left:52.8px;">
                                        <p><a href="{{ $social->linkdin }}">@mysalafispouse</a>
                                        </p>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <style type="text/css">
                        .fusion-body .fusion-builder-column-21 {
                            width: 33.333333333333% !important;
                            margin-top: 20px;
                            margin-bottom: 20px;
                        }

                        .fusion-builder-column-21>.fusion-column-wrapper {
                            padding-top: 0px !important;
                            padding-right: 0px !important;
                            margin-right: 5.76%;
                            padding-bottom: 0px !important;
                            padding-left: 0px !important;
                            margin-left: 5.76%;
                        }

                        @media only screen and (max-width:1024px) {
                            .fusion-body .fusion-builder-column-21 {
                                width: 33.333333333333% !important;
                                order: 0;
                            }

                            .fusion-builder-column-21>.fusion-column-wrapper {
                                margin-right: 5.76%;
                                margin-left: 5.76%;
                            }
                        }

                        @media only screen and (max-width:640px) {
                            .fusion-body .fusion-builder-column-21 {
                                width: 100% !important;
                                order: 0;
                            }

                            .fusion-builder-column-21>.fusion-column-wrapper {
                                margin-right: 1.92%;
                                margin-left: 1.92%;
                            }
                        }

                    </style>
                    <div
                        class="fusion-layout-column fusion_builder_column fusion-builder-column-22 fusion_builder_column_1_3 1_3 fusion-flex-column fusion-flex-align-self-center">
                        <div class="fusion-column-wrapper fusion-flex-justify-content-center fusion-content-layout-column"
                            style="background-position:left top;background-repeat:no-repeat;-webkit-background-size:cover;-moz-background-size:cover;-o-background-size:cover;background-size:cover;padding: 0px 0px 0px 0px;">
                            <ul class="fusion-checklist fusion-checklist-3" style="font-size:22px;line-height:37.4px;">
                                <li class="fusion-li-item"><span
                                        style="background-color:#ffffff;font-size:19.36px;height:37.4px;width:37.4px;margin-right:15.4px;"
                                        class="icon-wrapper circle-yes"><i class="fusion-li-icon fa-envelope fas"
                                            style="color:#000000;" aria-hidden="true"></i></span>
                                    <div class="fusion-li-item-content" style="margin-left:52.8px;">
                                        <p><a href="mailto:{{ $social->email }}">{{ $social->email }}</a>
                                        </p>
                                    </div>
                                </li>
                                <li class="fusion-li-item"><span
                                        style="background-color:#ffffff;font-size:19.36px;height:37.4px;width:37.4px;margin-right:15.4px;"
                                        class="icon-wrapper circle-yes"><i class="fusion-li-icon fa-map-marker-alt fas"
                                            style="color:#000000;" aria-hidden="true"></i></span>
                                    <div class="fusion-li-item-content" style="margin-left:52.8px;">
                                        <p>{{ $social->address }}</p>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <style type="text/css">
                        .fusion-body .fusion-builder-column-22 {
                            width: 33.333333333333% !important;
                            margin-top: 20px;
                            margin-bottom: 20px;
                        }

                        .fusion-builder-column-22>.fusion-column-wrapper {
                            padding-top: 0px !important;
                            padding-right: 0px !important;
                            margin-right: 5.76%;
                            padding-bottom: 0px !important;
                            padding-left: 0px !important;
                            margin-left: 5.76%;
                        }

                        @media only screen and (max-width:1024px) {
                            .fusion-body .fusion-builder-column-22 {
                                width: 33.333333333333% !important;
                                order: 0;
                            }

                            .fusion-builder-column-22>.fusion-column-wrapper {
                                margin-right: 5.76%;
                                margin-left: 5.76%;
                            }
                        }

                        @media only screen and (max-width:640px) {
                            .fusion-body .fusion-builder-column-22 {
                                width: 100% !important;
                                order: 0;
                            }

                            .fusion-builder-column-22>.fusion-column-wrapper {
                                margin-right: 1.92%;
                                margin-left: 1.92%;
                            }
                        }

                    </style>
                </div>
                <style type="text/css">
                    .fusion-body .fusion-flex-container.fusion-builder-row-7 {
                        padding-top: 50px;
                        margin-top: 0px;
                        padding-right: 32px;
                        padding-bottom: 40px;
                        margin-bottom: 0px;
                        padding-left: 32px;
                    }

                </style>
            </div>
        </div>
    </div>

</section>
