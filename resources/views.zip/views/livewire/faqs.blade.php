

    <div id="boxed-wrapper">
        <div class="fusion-sides-frame"></div>
        <div id="wrapper" class="fusion-wrapper">
            <main  class="clearfix width-100">
                <div class="fusion-row" style="max-width:100%;">
                    <section id="content" class="full-width">
                        <div id="post-3249" class="post-3249 page type-page status-publish hentry">
                            <span class="entry-title rich-snippet-hidden">FAQ&#8217;s</span><span
                                class="vcard rich-snippet-hidden"><span class="fn"><a
                                        href="https://mysalafispouse.com/author/devsite/" title="Posts by H"
                                        rel="author">H</a></span></span><span
                                class="updated rich-snippet-hidden">2021-07-27T02:08:45+00:00</span>
                            <div class="post-content">
                                <div class="fusion-fullwidth fullwidth-box fusion-builder-row-3 fusion-flex-container nonhundred-percent-fullwidth non-hundred-percent-height-scrolling"
                                    style="background-color: #02427d;background-position: center center;background-repeat: no-repeat;border-width: 0px 0px 0px 0px;border-color:rgba(0,0,0,0.08);border-style:solid;">
                                    <div class="fusion-builder-row fusion-row fusion-flex-align-items-flex-start"
                                        style="max-width:1372.8px;margin-left: calc(-4% / 2 );margin-right: calc(-4% / 2 );">
                                        <div
                                            class="fusion-layout-column fusion_builder_column fusion-builder-column-7 fusion_builder_column_1_1 1_1 fusion-flex-column">
                                            <div class="fusion-column-wrapper fusion-flex-justify-content-flex-start fusion-content-layout-column"
                                                style="background-position:left top;background-repeat:no-repeat;-webkit-background-size:cover;-moz-background-size:cover;-o-background-size:cover;background-size:cover;padding: 0px 0px 0px 0px;">
                                                <style type="text/css">
                                                    @media only screen and (max-width:1024px) {
                                                        .fusion-title.fusion-title-1 {
                                                            margin-top: 0px !important;
                                                            margin-bottom: 0px !important;
                                                        }
                                                    }

                                                    @media only screen and (max-width:640px) {
                                                        .fusion-title.fusion-title-1 {
                                                            margin-top: 12px !important;
                                                            margin-bottom: 24px !important;
                                                        }
                                                    }

                                                </style>
                                                <div class="fusion-title title fusion-title-1 fusion-sep-none fusion-title-center fusion-title-text fusion-title-size-one"
                                                    style="font-size:35px;margin-top:0px;margin-bottom:0px;">
                                                    <h1 class="title-heading-center"
                                                        style="margin:0;font-size:1em;color:#ffffff;">Frequently Asked
                                                        Questions</h1>
                                                </div>
                                            </div>
                                        </div>
                                        <style type="text/css">
                                            .fusion-body .fusion-builder-column-7 {
                                                width: 100% !important;
                                                margin-top: 0px;
                                                margin-bottom: 0px;
                                            }

                                            .fusion-builder-column-7>.fusion-column-wrapper {
                                                padding-top: 0 !important;
                                                padding-right: 0px !important;
                                                margin-right: 1.92%;
                                                padding-bottom: 0 !important;
                                                padding-left: 0px !important;
                                                margin-left: 1.92%;
                                            }

                                            @media only screen and (max-width:1024px) {
                                                .fusion-body .fusion-builder-column-7 {
                                                    width: 100% !important;
                                                    order: 0;
                                                }

                                                .fusion-builder-column-7>.fusion-column-wrapper {
                                                    margin-right: 1.92%;
                                                    margin-left: 1.92%;
                                                }
                                            }

                                            @media only screen and (max-width:640px) {
                                                .fusion-body .fusion-builder-column-7 {
                                                    width: 100% !important;
                                                    order: 0;
                                                }

                                                .fusion-builder-column-7>.fusion-column-wrapper {
                                                    margin-right: 1.92%;
                                                    margin-left: 1.92%;
                                                }
                                            }

                                        </style>
                                    </div>
                                    <style type="text/css">
                                        .fusion-body .fusion-flex-container.fusion-builder-row-3 {
                                            padding-top: 25px;
                                            margin-top: 0;
                                            padding-right: 32px;
                                            padding-bottom: 25px;
                                            margin-bottom: 0;
                                            padding-left: 32px;
                                        }

                                    </style>
                                </div>
                                <div class="fusion-fullwidth fullwidth-box fusion-builder-row-4 fusion-flex-container nonhundred-percent-fullwidth non-hundred-percent-height-scrolling"
                                    style="background-color: rgba(255,255,255,0);background-position: center center;background-repeat: no-repeat;border-width: 0px 0px 0px 0px;border-color:rgba(0,0,0,0.08);border-style:solid;">
                                    <div class="fusion-builder-row fusion-row fusion-flex-align-items-flex-start"
                                        style="max-width:1372.8px;margin-left: calc(-4% / 2 );margin-right: calc(-4% / 2 );">
                                        <div
                                            class="fusion-layout-column fusion_builder_column fusion-builder-column-8 fusion_builder_column_1_2 1_2 fusion-flex-column fusion-flex-align-self-center">
                                            <div class="fusion-column-wrapper fusion-flex-justify-content-center fusion-content-layout-column"
                                                style="background-position:left top;background-repeat:no-repeat;-webkit-background-size:cover;-moz-background-size:cover;-o-background-size:cover;background-size:cover;padding: 0px 0px 0px 0px;">
                                                <style type="text/css">
                                                    .fusion-accordian #accordion-3249-1 .panel-title a .fa-fusion-box {
                                                        color: #ffffff;
                                                    }

                                                    .fusion-accordian #accordion-3249-1 .panel-title a .fa-fusion-box:before {
                                                        font-size: 24px;
                                                        width: 24px;
                                                    }

                                                    .fusion-accordian #accordion-3249-1 .panel-title a {
                                                        font-size: 22px;
                                                    }

                                                    .fusion-accordian #accordion-3249-1 .panel-title a:hover,
                                                    #accordion-3249-1 .fusion-toggle-boxed-mode:hover .panel-title a {
                                                        color: #f86011;
                                                    }

                                                    .fusion-accordian #accordion-3249-1 .fusion-toggle-boxed-mode:hover .panel-title a .fa-fusion-box {
                                                        color: #f86011;
                                                    }

                                                    .fusion-accordian #accordion-3249-1.fusion-toggle-icon-unboxed .fusion-panel .panel-title a:hover .fa-fusion-box {
                                                        color: #f86011 !important;
                                                    }

                                                </style>
                                                <div class="accordian fusion-accordian">
                                                    <div class="panel-group fusion-toggle-icon-unboxed"
                                                        id="accordion-3249-1" role="tablist">
                                                        @php $sr = 1; @endphp
                                                        @foreach($faqs as $item)
                                                        <div class="fusion-panel panel-default fusion-toggle-no-divider"
                                                            role="tabpanel">
                                                            <div class="panel-heading">
                                                                <h4 class="panel-title toggle"><a aria-expanded="false"
                                                                        aria-selected="false"
                                                                        aria-controls="{{ $item->id }}" role="tab"
                                                                        data-toggle="collapse"
                                                                        data-parent="#accordion-3249-1"
                                                                        data-target="#{{ $item->id }}"
                                                                        href="#{{ $item->id }}"><span
                                                                            class="fusion-toggle-icon-wrapper"
                                                                            aria-hidden="true">
                                                                            <i class="fa fa-plus" style="color:blue;"
                                                                                aria-hidden="true"></i></span><span
                                                                            class="fusion-toggle-heading">{{ $sr++ }}) 
                                                                          {{ $item->question }}
                                                                        </span></a></h4>
                                                            </div>
                                                            <div id="{{ $item->id }}"
                                                                class="panel-collapse collapse ">
                                                                <div class="panel-body toggle-content fusion-clearfix">
                                                                    <p style="text-align: left;">
                                                                        {{ $item->answer }}
                                                                    </p>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        @endforeach
                                                        
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <style type="text/css">
                                            .fusion-body .fusion-builder-column-8 {
                                                width: 50% !important;
                                                margin-top: 20px;
                                                margin-bottom: 20px;
                                            }

                                            .fusion-builder-column-8>.fusion-column-wrapper {
                                                padding-top: 0px !important;
                                                padding-right: 0px !important;
                                                margin-right: 3.84%;
                                                padding-bottom: 0px !important;
                                                padding-left: 0px !important;
                                                margin-left: 3.84%;
                                            }

                                            @media only screen and (max-width:1024px) {
                                                .fusion-body .fusion-builder-column-8 {
                                                    width: 50% !important;
                                                    order: 0;
                                                }

                                                .fusion-builder-column-8>.fusion-column-wrapper {
                                                    margin-right: 3.84%;
                                                    margin-left: 3.84%;
                                                }
                                            }

                                            @media only screen and (max-width:640px) {
                                                .fusion-body .fusion-builder-column-8 {
                                                    width: 100% !important;
                                                    order: 0;
                                                }

                                                .fusion-builder-column-8>.fusion-column-wrapper {
                                                    margin-right: 1.92%;
                                                    margin-left: 1.92%;
                                                }
                                            }

                                        </style>
                                        <div
                                            class="fusion-layout-column fusion_builder_column fusion-builder-column-9 fusion_builder_column_1_2 1_2 fusion-flex-column">
                                            <div class="fusion-column-wrapper fusion-flex-justify-content-flex-start fusion-content-layout-column"
                                                style="background-position:left top;background-repeat:no-repeat;-webkit-background-size:cover;-moz-background-size:cover;-o-background-size:cover;background-size:cover;padding: 0px 0px 0px 0px;">
                                                <div><span
                                                        class=" fusion-imageframe imageframe-none imageframe-3 hover-type-none"
                                                        style="border-radius:8px;width:100%;max-width:380px;"><img
                                                            width="1798" height="1794"
                                                            title="Screenshot 2020-12-28 at 22.07.56"
                                                            src="https://mysalafispouse.com/wp-content/uploads/2020/12/Screenshot-2020-12-28-at-22.07.56.png"
                                                            data-orig-src="https://mysalafispouse.com/wp-content/uploads/2020/12/Screenshot-2020-12-28-at-22.07.56.png"
                                                            class="lazyload img-responsive wp-image-3565"
                                                            srcset="data:image/svg+xml,%3Csvg%20xmlns%3D%27http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%27%20width%3D%271798%27%20height%3D%271794%27%20viewBox%3D%270%200%201798%201794%27%3E%3Crect%20width%3D%271798%27%20height%3D%2731794%27%20fill-opacity%3D%220%22%2F%3E%3C%2Fsvg%3E"
                                                            data-srcset="https://mysalafispouse.com/wp-content/uploads/2020/12/Screenshot-2020-12-28-at-22.07.56-200x200.png 200w, https://mysalafispouse.com/wp-content/uploads/2020/12/Screenshot-2020-12-28-at-22.07.56-400x399.png 400w, https://mysalafispouse.com/wp-content/uploads/2020/12/Screenshot-2020-12-28-at-22.07.56-600x599.png 600w, https://mysalafispouse.com/wp-content/uploads/2020/12/Screenshot-2020-12-28-at-22.07.56-800x798.png 800w, https://mysalafispouse.com/wp-content/uploads/2020/12/Screenshot-2020-12-28-at-22.07.56-1200x1197.png 1200w, https://mysalafispouse.com/wp-content/uploads/2020/12/Screenshot-2020-12-28-at-22.07.56.png 1798w"
                                                            data-sizes="auto"
                                                            data-orig-sizes="(max-width: 640px) 100vw, 800px" /></span>
                                                </div>
                                            </div>
                                        </div>
                                        <style type="text/css">
                                            .fusion-body .fusion-builder-column-9 {
                                                width: 50% !important;
                                                margin-top: 20px;
                                                margin-bottom: 20px;
                                            }

                                            .fusion-builder-column-9>.fusion-column-wrapper {
                                                padding-top: 0px !important;
                                                padding-right: 0px !important;
                                                margin-right: 3.84%;
                                                padding-bottom: 0px !important;
                                                padding-left: 0px !important;
                                                margin-left: 3.84%;
                                            }

                                            @media only screen and (max-width:1024px) {
                                                .fusion-body .fusion-builder-column-9 {
                                                    width: 50% !important;
                                                    order: 0;
                                                }

                                                .fusion-builder-column-9>.fusion-column-wrapper {
                                                    margin-right: 3.84%;
                                                    margin-left: 3.84%;
                                                }
                                            }

                                            @media only screen and (max-width:640px) {
                                                .fusion-body .fusion-builder-column-9 {
                                                    width: 100% !important;
                                                    order: 0;
                                                }

                                                .fusion-builder-column-9>.fusion-column-wrapper {
                                                    margin-right: 1.92%;
                                                    margin-left: 1.92%;
                                                }
                                            }

                                        </style>
                                    </div>
                                    <style type="text/css">
                                        .fusion-body .fusion-flex-container.fusion-builder-row-4 {
                                            padding-top: 50px;
                                            margin-top: 0px;
                                            padding-right: 32px;
                                            padding-bottom: 40px;
                                            margin-bottom: 0px;
                                            padding-left: 32px;
                                        }

                                    </style>
                                </div>
                            </div>
                        </div>
                    </section>

                </div> <!-- fusion-row -->
            </main> <!-- #main -->
            <div class="fusion-sliding-bar-wrapper">
            </div>
        </div> 
        <!-- wrapper -->
    </div> 
    <!-- #boxed-wrapper -->
    <div class="fusion-top-frame"></div>
    <div class="fusion-bottom-frame"></div>
    <div class="fusion-boxed-shadow"></div>
    <a class="fusion-one-page-text-link fusion-page-load-link"></a>




<!-- Page generated by LiteSpeed Cache 4.2 on 2021-08-16 01:01:46 -->
