<main id="main" class="clearfix width-100">
	<div class="fusion-row" style="max-width:100%;">
		<section id="content" class="full-width">
			<div id="post-2886" class="post-2886 page type-page status-publish hentry">
			
				<div class="post-content">
					<div class="fusion-fullwidth fullwidth-box fusion-builder-row-3 fusion-flex-container nonhundred-percent-fullwidth non-hundred-percent-height-scrolling"
						style="background-color: #02427d;background-position: center center;background-repeat: no-repeat;border-width: 0px 0px 0px 0px;border-color:rgba(0,0,0,0.08);border-style:solid;">
						<div class="fusion-builder-row fusion-row fusion-flex-align-items-flex-start"
							style="max-width:1372.8px;margin-left: calc(-4% / 2 );margin-right: calc(-4% / 2 );">
							<div
								class="fusion-layout-column fusion_builder_column fusion-builder-column-7 fusion_builder_column_1_1 1_1 fusion-flex-column">
								<div class="fusion-column-wrapper fusion-flex-justify-content-flex-start fusion-content-layout-column"
									style="background-position:left top;background-repeat:no-repeat;-webkit-background-size:cover;-moz-background-size:cover;-o-background-size:cover;background-size:cover;padding: 0px 0px 0px 0px;">
									<style type="text/css">
										@media only screen and (max-width:1024px) {
											.fusion-title.fusion-title-1 {
												margin-top: 0px !important;
												margin-bottom: 0px !important;
											}
										}

										@media only screen and (max-width:640px) {
											.fusion-title.fusion-title-1 {
												margin-top: 12px !important;
												margin-bottom: 24px !important;
											}
										}

									</style>
									<div class="fusion-title title fusion-title-1 fusion-sep-none fusion-title-center fusion-title-text fusion-title-size-one"
										style="font-size:35px;margin-top:0px;margin-bottom:0px;">
										<h1 class="title-heading-center"
											style="margin:0;font-size:1em;color:#ffffff;">THE MATCHMAKING
											PROCESS</h1>
									</div>
								</div>
							</div>
							<style type="text/css">
								.fusion-body .fusion-builder-column-7 {
									width: 100% !important;
									margin-top: 0px;
									margin-bottom: 0px;
								}

								.fusion-builder-column-7>.fusion-column-wrapper {
									padding-top: 0 !important;
									padding-right: 0px !important;
									margin-right: 1.92%;
									padding-bottom: 0 !important;
									padding-left: 0px !important;
									margin-left: 1.92%;
								}

								@media only screen and (max-width:1024px) {
									.fusion-body .fusion-builder-column-7 {
										width: 100% !important;
										order: 0;
									}

									.fusion-builder-column-7>.fusion-column-wrapper {
										margin-right: 1.92%;
										margin-left: 1.92%;
									}
								}

								@media only screen and (max-width:640px) {
									.fusion-body .fusion-builder-column-7 {
										width: 100% !important;
										order: 0;
									}

									.fusion-builder-column-7>.fusion-column-wrapper {
										margin-right: 1.92%;
										margin-left: 1.92%;
									}
								}

							</style>
						</div>
						<style type="text/css">
							.fusion-body .fusion-flex-container.fusion-builder-row-3 {
								padding-top: 25px;
								margin-top: 0;
								padding-right: 32px;
								padding-bottom: 25px;
								margin-bottom: 0;
								padding-left: 32px;
							}

						</style>
					</div>
					<div class="fusion-fullwidth fullwidth-box fusion-builder-row-4 fusion-flex-container nonhundred-percent-fullwidth non-hundred-percent-height-scrolling"
						style="background-color: #ffffff;background-image:linear-gradient(180deg, rgba(2,66,125,0.02) 0%,rgba(2,29,124,0) 100%);background-position: center center;background-repeat: no-repeat;border-width: 0px 0px 0px 0px;border-color:rgba(0,0,0,0.08);border-style:solid;">
						<div class="fusion-builder-row fusion-row fusion-flex-align-items-flex-start"
							style="max-width:1372.8px;margin-left: calc(-4% / 2 );margin-right: calc(-4% / 2 );">
							<div
								class="fusion-layout-column fusion_builder_column fusion-builder-column-8 fusion_builder_column_1_1 1_1 fusion-flex-column">
								<div class="fusion-column-wrapper fusion-flex-justify-content-flex-start fusion-content-layout-column"
									style="background-position:left top;background-repeat:no-repeat;-webkit-background-size:cover;-moz-background-size:cover;-o-background-size:cover;background-size:cover;padding: 0px 0px 0px 0px;">
									<style type="text/css">
										@media only screen and (max-width:1024px) {
											.fusion-title.fusion-title-2 {
												margin-top: 12px !important;
												margin-bottom: 24px !important;
											}
										}

										@media only screen and (max-width:640px) {
											.fusion-title.fusion-title-2 {
												margin-top: 12px !important;
												margin-bottom: 24px !important;
											}
										}

									</style>
									<div class="fusion-title title fusion-title-2 fusion-sep-none fusion-title-center fusion-title-text fusion-title-size-one"
										style="font-size:50px;margin-top:12px;margin-bottom:24px;">
										<h1 class="title-heading-center"
											style="font-family:&quot;Poppins&quot;;font-weight:500;margin:0;font-size:1em;color:#000000;">
											A 3-STAGE EASY PROCESS!</h1>
									</div>
									<div class="fusion-text fusion-text-1">
										<p style="text-align: center;"><span style="color: #000000;">We will
												create a profile for you, post it on our Instagram page and
												directly send it to profiles you are interested in. If
												anyone else is interested in your profile we will send you
												their profile also. If you are interested in any other
												profile you can inform us their profile code also.</span>
										</p>
										<p style="text-align: center;"><span style="color: #000000;">We will
												protect your identity by facilitating your communication and
												sending messages through us, this will enable both parties
												to communicate through us with a barrier. Once you are both
												happy to proceed to the next stage, the sister (female
												applicant) must send us her Wali&#8217;s (guardian) details
												across and we will send that to the brother (male
												applicant).</span></p>
									</div>
								</div>
							</div>
							<style type="text/css">
								.fusion-body .fusion-builder-column-8 {
									width: 100% !important;
									margin-top: 20px;
									margin-bottom: 20px;
								}

								.fusion-builder-column-8>.fusion-column-wrapper {
									padding-top: 0px !important;
									padding-right: 0px !important;
									margin-right: 1.92%;
									padding-bottom: 0px !important;
									padding-left: 0px !important;
									margin-left: 1.92%;
								}

								@media only screen and (max-width:1024px) {
									.fusion-body .fusion-builder-column-8 {
										width: 100% !important;
										order: 0;
									}

									.fusion-builder-column-8>.fusion-column-wrapper {
										margin-right: 1.92%;
										margin-left: 1.92%;
									}
								}

								@media only screen and (max-width:640px) {
									.fusion-body .fusion-builder-column-8 {
										width: 100% !important;
										order: 0;
									}

									.fusion-builder-column-8>.fusion-column-wrapper {
										margin-right: 1.92%;
										margin-left: 1.92%;
									}
								}

							</style>
							<div
								class="fusion-layout-column fusion_builder_column fusion-builder-column-9 fusion_builder_column_1_3 1_3 fusion-flex-column">
								<div class="fusion-column-wrapper fusion-flex-justify-content-flex-start fusion-content-layout-column"
									style="background-position:left top;background-repeat:no-repeat;-webkit-background-size:cover;-moz-background-size:cover;-o-background-size:cover;background-size:cover;border-radius:5px 5px 5px 5px;background-color:#ffffff;border-width: 1px 1px 1px 1px;border-color:#c1c1c1;border-style:solid;border-radius:5px 5px 5px 5px;overflow:hidden;padding: 70px 30px 71px 30px;">
									<div style="text-align:center;"><span
											class=" fusion-imageframe imageframe-none imageframe-3 hover-type-none"
											style="border-radius:200px;width:100%;max-width:180px;margin-top:40px;margin-right:10px;margin-bottom:10px;margin-left:10px;"><img
												width="1796" height="1798"
												title="Screenshot 2020-12-12 at 22.30.34"
												src="{{ url('/site/images') }}/Screenshot-2020-12-12-at-22.30.34.png"
												data-sizes="auto"
												data-orig-sizes="(max-width: 640px) 100vw, 400px" /></span>
									</div>
									<div class="fusion-builder-row fusion-builder-row-inner fusion-row fusion-flex-align-items-flex-start"
										style="width:104% !important;max-width:104% !important;margin-left: calc(-4% / 2 );margin-right: calc(-4% / 2 );">
										<div
											class="fusion-layout-column fusion_builder_column_inner fusion-builder-nested-column-0 fusion_builder_column_inner_1_1 1_1 fusion-flex-column">
											<div class="fusion-column-wrapper fusion-flex-justify-content-flex-start fusion-content-layout-column"
												style="background-position:left top;background-repeat:no-repeat;-webkit-background-size:cover;-moz-background-size:cover;-o-background-size:cover;background-size:cover;padding: 0px 10px 0px 10px;">
												<style type="text/css">
													@media only screen and (max-width:1024px) {
														.fusion-title.fusion-title-3 {
															margin-top: 5px !important;
															margin-bottom: 5px !important;
														}
													}

													@media only screen and (max-width:640px) {
														.fusion-title.fusion-title-3 {
															margin-top: 12px !important;
															margin-bottom: 24px !important;
														}
													}

												</style>
												<div class="fusion-title title fusion-title-3 fusion-sep-none fusion-title-center fusion-title-text fusion-title-size-one"
													style="font-size:20px;margin-top:5px;margin-bottom:5px;">
													<h1 class="title-heading-center"
														style="margin:0;font-size:1em;color:#000000;"><span
															style="color: #dd1922;">Stage 1: Sign Up!</span>
													</h1>
												</div>
												<div class="fusion-text fusion-text-2"
													style="text-align:center;font-size:15px;">
													<p><span style="color: #000000;">Fill out a quick form
															and our team will pick up your application. All
															Male applicants are dealt with by a brother. All
															Female applicants are dealt with by a sister.
															We&#8217;ll create a unique profile tailored to
															you!</span></p>
												</div>
												<div style="text-align:center;">
													<style type="text/css">
														.fusion-button.button-1 .fusion-button-text,
														.fusion-button.button-1 i {
															color: #000000;
														}

														.fusion-button.button-1 .fusion-button-icon-divider {
															border-color: #000000;
														}

														.fusion-button.button-1:hover .fusion-button-text,
														.fusion-button.button-1:hover i,
														.fusion-button.button-1:focus .fusion-button-text,
														.fusion-button.button-1:focus i,
														.fusion-button.button-1:active .fusion-button-text,
														.fusion-button.button-1:active {
															color: #ffffff;
														}

														.fusion-button.button-1:hover .fusion-button-icon-divider,
														.fusion-button.button-1:hover .fusion-button-icon-divider,
														.fusion-button.button-1:active .fusion-button-icon-divider {
															border-color: #ffffff;
														}

														.fusion-button.button-1:hover,
														.fusion-button.button-1:focus,
														.fusion-button.button-1:active {
															border-color: #ffffff;
														}

														.fusion-button.button-1 {
															border-color: #ffffff;
															border-radius: 26px;
														}

														.fusion-button.button-1 {
															background: #ffffff;
														}

														.fusion-button.button-1:hover,
														.button-1:focus,
														.fusion-button.button-1:active {
															background: #000000;
														}

													</style><a
														class="fusion-button button-flat button-medium button-custom button-1 fusion-button-default-span fusion-button-default-type"
														target="_self"
														href="{{ url('/want-to-signup') }}"><span
															class="fusion-button-text">I WANT TO SIGN
															UP!</span></a>
												</div>
											</div>
										</div>
										<style type="text/css">
											.fusion-body .fusion-builder-nested-column-0 {
												width: 100% !important;
												margin-top: 20px;
												margin-bottom: 20px;
											}

											.fusion-builder-nested-column-0>.fusion-column-wrapper {
												padding-top: 0px !important;
												padding-right: 10px !important;
												margin-right: 1.92%;
												padding-bottom: 0px !important;
												padding-left: 10px !important;
												margin-left: 1.92%;
											}

											@media only screen and (max-width:1024px) {
												.fusion-body .fusion-builder-nested-column-0 {
													width: 100% !important;
													order: 0;
												}

												.fusion-builder-nested-column-0>.fusion-column-wrapper {
													margin-right: 1.92%;
													margin-left: 1.92%;
												}
											}

											@media only screen and (max-width:640px) {
												.fusion-body .fusion-builder-nested-column-0 {
													width: 100% !important;
													order: 0;
												}

												.fusion-builder-nested-column-0>.fusion-column-wrapper {
													margin-right: 1.92%;
													margin-left: 1.92%;
												}
											}

										</style>
									</div>
								</div>
							</div>
							<style type="text/css">
								.fusion-body .fusion-builder-column-9 {
									width: 33.333333333333% !important;
									margin-top: 20px;
									margin-bottom: 20px;
								}

								.fusion-builder-column-9>.fusion-column-wrapper {
									padding-top: 70 !important;
									padding-right: 30 !important;
									margin-right: 5.76%;
									padding-bottom: 71px !important;
									padding-left: 30 !important;
									margin-left: 5.76%;
								}

								@media only screen and (max-width:1024px) {
									.fusion-body .fusion-builder-column-9 {
										width: 33.333333333333% !important;
										order: 0;
									}

									.fusion-builder-column-9>.fusion-column-wrapper {
										margin-right: 5.76%;
										margin-left: 5.76%;
									}
								}

								@media only screen and (max-width:640px) {
									.fusion-body .fusion-builder-column-9 {
										width: 100% !important;
										order: 0;
									}

									.fusion-builder-column-9>.fusion-column-wrapper {
										margin-right: 1.92%;
										margin-left: 1.92%;
									}
								}

							</style>
							<div
								class="fusion-layout-column fusion_builder_column fusion-builder-column-10 fusion_builder_column_1_3 1_3 fusion-flex-column">
								<div class="fusion-column-wrapper fusion-flex-justify-content-flex-start fusion-content-layout-column"
									style="background-position:left top;background-repeat:no-repeat;-webkit-background-size:cover;-moz-background-size:cover;-o-background-size:cover;background-size:cover;border-radius:5px 5px 5px 5px;background-color:#fffcfc;border-width: 1px 1px 1px 1px;border-color:#c1c1c1;border-style:solid;border-radius:5px 5px 5px 5px;overflow:hidden;padding: 50px 30px 114px 30px;">
									<div style="text-align:center;"><span
											class=" fusion-imageframe imageframe-none imageframe-4 hover-type-none"
											style="border-radius:100px;width:100%;max-width:180px;margin-top:40px;margin-right:10px;margin-bottom:10px;margin-left:10px;"><img
												width="1796" height="1798"
												title="Screenshot 2020-12-12 at 22.30.50"
												src="{{ url('/site/images') }}/Screenshot-2020-12-12-at-22.30.50.png"
												
												data-sizes="auto"
												data-orig-sizes="(max-width: 640px) 100vw, 400px" /></span>
									</div>
									<div class="fusion-builder-row fusion-builder-row-inner fusion-row fusion-flex-align-items-flex-start"
										style="width:104% !important;max-width:104% !important;margin-left: calc(-4% / 2 );margin-right: calc(-4% / 2 );">
										<div
											class="fusion-layout-column fusion_builder_column_inner fusion-builder-nested-column-1 fusion_builder_column_inner_1_1 1_1 fusion-flex-column">
											<div class="fusion-column-wrapper fusion-flex-justify-content-flex-start fusion-content-layout-column"
												style="background-position:left top;background-repeat:no-repeat;-webkit-background-size:cover;-moz-background-size:cover;-o-background-size:cover;background-size:cover;padding: 0px 10px 0px 10px;">
												<style type="text/css">
													@media only screen and (max-width:1024px) {
														.fusion-title.fusion-title-4 {
															margin-top: 5px !important;
															margin-bottom: 5px !important;
														}
													}

													@media only screen and (max-width:640px) {
														.fusion-title.fusion-title-4 {
															margin-top: 12px !important;
															margin-bottom: 24px !important;
														}
													}

												</style>
												<div class="fusion-title title fusion-title-4 fusion-sep-none fusion-title-center fusion-title-text fusion-title-size-one"
													style="font-size:20px;margin-top:5px;margin-bottom:5px;">
													<h1 class="title-heading-center"
														style="margin:0;font-size:1em;"><span
															style="color: #dd1922;">Stage 2: The
															Matchmaking!</span></h1>
												</div>
												<div class="fusion-text fusion-text-3"
													style="text-align:center;font-size:15px;">
													<p><span style="color: #000000;">Match request profiles
															on our database that you are interested in.
															<span
																style="font-family: var(--body_typography-font-family); font-style: var(--body_typography-font-style,normal); letter-spacing: var(--body_typography-letter-spacing);">We’ll
																also recommend you to match request any
																profiles we think are compatible with
																you!</span></span></p>
												</div>
												<div style="text-align:center;">
													<style type="text/css">
														.fusion-button.button-2 .fusion-button-text,
														.fusion-button.button-2 i {
															color: #000000;
														}

														.fusion-button.button-2 .fusion-button-icon-divider {
															border-color: #000000;
														}

														.fusion-button.button-2:hover .fusion-button-text,
														.fusion-button.button-2:hover i,
														.fusion-button.button-2:focus .fusion-button-text,
														.fusion-button.button-2:focus i,
														.fusion-button.button-2:active .fusion-button-text,
														.fusion-button.button-2:active {
															color: #ffffff;
														}

														.fusion-button.button-2:hover .fusion-button-icon-divider,
														.fusion-button.button-2:hover .fusion-button-icon-divider,
														.fusion-button.button-2:active .fusion-button-icon-divider {
															border-color: #ffffff;
														}

														.fusion-button.button-2:hover,
														.fusion-button.button-2:focus,
														.fusion-button.button-2:active {
															border-color: #ffffff;
														}

														.fusion-button.button-2 {
															border-color: #ffffff;
															border-radius: 26px;
														}

														.fusion-button.button-2 {
															background: #ffffff;
														}

														.fusion-button.button-2:hover,
														.button-2:focus,
														.fusion-button.button-2:active {
															background: #000000;
														}

													</style><a
														class="fusion-button button-flat button-medium button-custom button-2 fusion-button-default-span fusion-button-default-type"
														target="_self"
														href="{{ url('/want-to-signup') }}"><span
															class="fusion-button-text">I WANT TO SIGN
															UP!</span></a>
												</div>
											</div>
										</div>
										<style type="text/css">
											.fusion-body .fusion-builder-nested-column-1 {
												width: 100% !important;
												margin-top: 20px;
												margin-bottom: 20px;
											}

											.fusion-builder-nested-column-1>.fusion-column-wrapper {
												padding-top: 0px !important;
												padding-right: 10px !important;
												margin-right: 1.92%;
												padding-bottom: 0px !important;
												padding-left: 10px !important;
												margin-left: 1.92%;
											}

											@media only screen and (max-width:1024px) {
												.fusion-body .fusion-builder-nested-column-1 {
													width: 100% !important;
													order: 0;
												}

												.fusion-builder-nested-column-1>.fusion-column-wrapper {
													margin-right: 1.92%;
													margin-left: 1.92%;
												}
											}

											@media only screen and (max-width:640px) {
												.fusion-body .fusion-builder-nested-column-1 {
													width: 100% !important;
													order: 0;
												}

												.fusion-builder-nested-column-1>.fusion-column-wrapper {
													margin-right: 1.92%;
													margin-left: 1.92%;
												}
											}

										</style>
									</div>
								</div>
							</div>
							<style type="text/css">
								.fusion-body .fusion-builder-column-10 {
									width: 33.333333333333% !important;
									margin-top: 20px;
									margin-bottom: 20px;
								}

								.fusion-builder-column-10>.fusion-column-wrapper {
									padding-top: 50 !important;
									padding-right: 30 !important;
									margin-right: 5.76%;
									padding-bottom: 114px !important;
									padding-left: 30 !important;
									margin-left: 5.76%;
								}

								@media only screen and (max-width:1024px) {
									.fusion-body .fusion-builder-column-10 {
										width: 33.333333333333% !important;
										order: 0;
									}

									.fusion-builder-column-10>.fusion-column-wrapper {
										margin-right: 5.76%;
										margin-left: 5.76%;
									}
								}

								@media only screen and (max-width:640px) {
									.fusion-body .fusion-builder-column-10 {
										width: 100% !important;
										order: 0;
									}

									.fusion-builder-column-10>.fusion-column-wrapper {
										margin-right: 1.92%;
										margin-left: 1.92%;
									}
								}

							</style>
							<div
								class="fusion-layout-column fusion_builder_column fusion-builder-column-11 fusion_builder_column_1_3 1_3 fusion-flex-column">
								<div class="fusion-column-wrapper fusion-flex-justify-content-flex-start fusion-content-layout-column"
									style="background-position:left top;background-repeat:no-repeat;-webkit-background-size:cover;-moz-background-size:cover;-o-background-size:cover;background-size:cover;border-radius:5px 5px 5px 5px;background-color:#fffcfc;border-width: 1px 1px 1px 1px;border-color:#c1c1c1;border-style:solid;border-radius:5px 5px 5px 5px;overflow:hidden;padding: 80px 30px 90px 30px;">
									<div style="text-align:center;"><span
											class=" fusion-imageframe imageframe-none imageframe-5 hover-type-none"
											style="border-radius:100px;width:100%;max-width:180px;margin-top:40px;margin-right:10px;margin-bottom:10px;margin-left:10px;"><img
												width="227" height="106" title="23"
												src="{{ url('site/images') }}/23-1.png"
												data-sizes="auto"
												data-orig-sizes="(max-width: 640px) 100vw, 227px" /></span>
									</div>
									<div class="fusion-builder-row fusion-builder-row-inner fusion-row fusion-flex-align-items-flex-start"
										style="width:104% !important;max-width:104% !important;margin-left: calc(-4% / 2 );margin-right: calc(-4% / 2 );">
										<div
											class="fusion-layout-column fusion_builder_column_inner fusion-builder-nested-column-2 fusion_builder_column_inner_1_1 1_1 fusion-flex-column">
											<div class="fusion-column-wrapper fusion-flex-justify-content-flex-start fusion-content-layout-column"
												style="background-position:left top;background-repeat:no-repeat;-webkit-background-size:cover;-moz-background-size:cover;-o-background-size:cover;background-size:cover;padding: 0px 10px 0px 10px;">
												<style type="text/css">
													@media only screen and (max-width:1024px) {
														.fusion-title.fusion-title-5 {
															margin-top: 5px !important;
															margin-bottom: 5px !important;
														}
													}

													@media only screen and (max-width:640px) {
														.fusion-title.fusion-title-5 {
															margin-top: 12px !important;
															margin-bottom: 24px !important;
														}
													}

												</style>
												<div class="fusion-title title fusion-title-5 fusion-sep-none fusion-title-center fusion-title-text fusion-title-size-one"
													style="font-size:20px;margin-top:5px;margin-bottom:5px;">
													<h1 class="title-heading-center"
														style="margin:0;font-size:1em;"><span
															style="color: #dd1922;">Stage 3: The Marriage
															Meeting!</span></h1>
												</div>
												<div class="fusion-text fusion-text-4"
													style="text-align:center;font-size:15px;">
													<p><span style="color: #000000;">If you&#8217;re happy
															with your match, we’ll even help you by setting
															up a marriage meeting with your potential
															spouse. Sisters must provide us with their
															Wali’s contact info and we will send that
															directly to the brother. Thereafter, he can
															contact her Wali directly to arrange a
															meeting.</span></p>
												</div>
												<div style="text-align:center;">
													<style type="text/css">
														.fusion-button.button-3 .fusion-button-text,
														.fusion-button.button-3 i {
															color: #000000;
														}

														.fusion-button.button-3 .fusion-button-icon-divider {
															border-color: #000000;
														}

														.fusion-button.button-3:hover .fusion-button-text,
														.fusion-button.button-3:hover i,
														.fusion-button.button-3:focus .fusion-button-text,
														.fusion-button.button-3:focus i,
														.fusion-button.button-3:active .fusion-button-text,
														.fusion-button.button-3:active {
															color: #ffffff;
														}

														.fusion-button.button-3:hover .fusion-button-icon-divider,
														.fusion-button.button-3:hover .fusion-button-icon-divider,
														.fusion-button.button-3:active .fusion-button-icon-divider {
															border-color: #ffffff;
														}

														.fusion-button.button-3:hover,
														.fusion-button.button-3:focus,
														.fusion-button.button-3:active {
															border-color: #ffffff;
														}

														.fusion-button.button-3 {
															border-color: #ffffff;
															border-radius: 26px;
														}

														.fusion-button.button-3 {
															background: #ffffff;
														}

														.fusion-button.button-3:hover,
														.button-3:focus,
														.fusion-button.button-3:active {
															background: #000000;
														}

													</style><a
														class="fusion-button button-flat button-medium button-custom button-3 fusion-button-default-span fusion-button-default-type"
														target="_self"
														href="{{ url('/want-to-signup') }}"><span
															class="fusion-button-text">I WANT TO SIGN
															UP!</span></a>
												</div>
											</div>
										</div>
										<style type="text/css">
											.fusion-body .fusion-builder-nested-column-2 {
												width: 100% !important;
												margin-top: 20px;
												margin-bottom: 20px;
											}

											.fusion-builder-nested-column-2>.fusion-column-wrapper {
												padding-top: 0px !important;
												padding-right: 10px !important;
												margin-right: 1.92%;
												padding-bottom: 0px !important;
												padding-left: 10px !important;
												margin-left: 1.92%;
											}

											@media only screen and (max-width:1024px) {
												.fusion-body .fusion-builder-nested-column-2 {
													width: 100% !important;
													order: 0;
												}

												.fusion-builder-nested-column-2>.fusion-column-wrapper {
													margin-right: 1.92%;
													margin-left: 1.92%;
												}
											}

											@media only screen and (max-width:640px) {
												.fusion-body .fusion-builder-nested-column-2 {
													width: 100% !important;
													order: 0;
												}

												.fusion-builder-nested-column-2>.fusion-column-wrapper {
													margin-right: 1.92%;
													margin-left: 1.92%;
												}
											}

										</style>
									</div>
								</div>
							</div>
							<style type="text/css">
								.fusion-body .fusion-builder-column-11 {
									width: 33.333333333333% !important;
									margin-top: 20px;
									margin-bottom: 20px;
								}

								.fusion-builder-column-11>.fusion-column-wrapper {
									padding-top: 80 !important;
									padding-right: 30 !important;
									margin-right: 5.76%;
									padding-bottom: 90 !important;
									padding-left: 30 !important;
									margin-left: 5.76%;
								}

								@media only screen and (max-width:1024px) {
									.fusion-body .fusion-builder-column-11 {
										width: 33.333333333333% !important;
										order: 0;
									}

									.fusion-builder-column-11>.fusion-column-wrapper {
										margin-right: 5.76%;
										margin-left: 5.76%;
									}
								}

								@media only screen and (max-width:640px) {
									.fusion-body .fusion-builder-column-11 {
										width: 100% !important;
										order: 0;
									}

									.fusion-builder-column-11>.fusion-column-wrapper {
										margin-right: 1.92%;
										margin-left: 1.92%;
									}
								}

							</style>
							<div
								class="fusion-layout-column fusion_builder_column fusion-builder-column-12 fusion_builder_column_1_4 1_4 fusion-flex-column">
								<div class="fusion-column-wrapper fusion-flex-justify-content-flex-start fusion-content-layout-column"
									style="background-position:left top;background-repeat:no-repeat;-webkit-background-size:cover;-moz-background-size:cover;-o-background-size:cover;background-size:cover;padding: 0px 0px 0px 0px;">
								</div>
							</div>
							<style type="text/css">
								.fusion-body .fusion-builder-column-12 {
									width: 25% !important;
									margin-top: 20px;
									margin-bottom: 20px;
								}

								.fusion-builder-column-12>.fusion-column-wrapper {
									padding-top: 0px !important;
									padding-right: 0px !important;
									margin-right: 7.68%;
									padding-bottom: 0px !important;
									padding-left: 0px !important;
									margin-left: 7.68%;
								}

								@media only screen and (max-width:1024px) {
									.fusion-body .fusion-builder-column-12 {
										width: 25% !important;
										order: 0;
									}

									.fusion-builder-column-12>.fusion-column-wrapper {
										margin-right: 7.68%;
										margin-left: 7.68%;
									}
								}

								@media only screen and (max-width:640px) {
									.fusion-body .fusion-builder-column-12 {
										width: 100% !important;
										order: 0;
									}

									.fusion-builder-column-12>.fusion-column-wrapper {
										margin-right: 1.92%;
										margin-left: 1.92%;
									}
								}

							</style>
							<div
								class="fusion-layout-column fusion_builder_column fusion-builder-column-13 fusion_builder_column_1_2 1_2 fusion-flex-column">
								<div class="fusion-column-wrapper fusion-flex-justify-content-flex-start fusion-content-layout-column"
									style="background-position:left top;background-repeat:no-repeat;-webkit-background-size:cover;-moz-background-size:cover;-o-background-size:cover;background-size:cover;padding: 0px 0px 0px 0px;">
									<div style="text-align:center;">
										<style type="text/css">
											.fusion-button.button-4 .fusion-button-text,
											.fusion-button.button-4 i {
												color: #000000;
											}

											.fusion-button.button-4 .fusion-button-icon-divider {
												border-color: #000000;
											}

											.fusion-button.button-4:hover .fusion-button-text,
											.fusion-button.button-4:hover i,
											.fusion-button.button-4:focus .fusion-button-text,
											.fusion-button.button-4:focus i,
											.fusion-button.button-4:active .fusion-button-text,
											.fusion-button.button-4:active {
												color: #ffffff;
											}

											.fusion-button.button-4:hover .fusion-button-icon-divider,
											.fusion-button.button-4:hover .fusion-button-icon-divider,
											.fusion-button.button-4:active .fusion-button-icon-divider {
												border-color: #ffffff;
											}

											.fusion-button.button-4:hover,
											.fusion-button.button-4:focus,
											.fusion-button.button-4:active {
												border-color: #ffffff;
											}

											.fusion-button.button-4 {
												border-color: #ffffff;
												border-radius: 5px;
											}

											.fusion-button.button-4 {
												background: #ffffff;
											}

											.fusion-button.button-4:hover,
											.button-4:focus,
											.fusion-button.button-4:active {
												background: #000000;
											}

										</style><a
											class="fusion-button button-flat button-xlarge button-custom button-4 fusion-button-default-span "
											target="_self"
											href="{{ url('/want-to-signup') }}"><span
												class="fusion-button-text">I WANT TO SIGN UP!</span></a>
									</div>
								</div>
							</div>
							<style type="text/css">
								.fusion-body .fusion-builder-column-13 {
									width: 50% !important;
									margin-top: 20px;
									margin-bottom: 20px;
								}

								.fusion-builder-column-13>.fusion-column-wrapper {
									padding-top: 0px !important;
									padding-right: 0px !important;
									margin-right: 3.84%;
									padding-bottom: 0px !important;
									padding-left: 0px !important;
									margin-left: 3.84%;
								}

								@media only screen and (max-width:1024px) {
									.fusion-body .fusion-builder-column-13 {
										width: 50% !important;
										order: 0;
									}

									.fusion-builder-column-13>.fusion-column-wrapper {
										margin-right: 3.84%;
										margin-left: 3.84%;
									}
								}

								@media only screen and (max-width:640px) {
									.fusion-body .fusion-builder-column-13 {
										width: 100% !important;
										order: 0;
									}

									.fusion-builder-column-13>.fusion-column-wrapper {
										margin-right: 1.92%;
										margin-left: 1.92%;
									}
								}

							</style>
							<div
								class="fusion-layout-column fusion_builder_column fusion-builder-column-14 fusion_builder_column_1_4 1_4 fusion-flex-column">
								<div class="fusion-column-wrapper fusion-flex-justify-content-flex-start fusion-content-layout-column"
									style="background-position:left top;background-repeat:no-repeat;-webkit-background-size:cover;-moz-background-size:cover;-o-background-size:cover;background-size:cover;padding: 0px 0px 0px 0px;">
								</div>
							</div>
							<style type="text/css">
								.fusion-body .fusion-builder-column-14 {
									width: 25% !important;
									margin-top: 20px;
									margin-bottom: 20px;
								}

								.fusion-builder-column-14>.fusion-column-wrapper {
									padding-top: 0px !important;
									padding-right: 0px !important;
									margin-right: 7.68%;
									padding-bottom: 0px !important;
									padding-left: 0px !important;
									margin-left: 7.68%;
								}

								@media only screen and (max-width:1024px) {
									.fusion-body .fusion-builder-column-14 {
										width: 25% !important;
										order: 0;
									}

									.fusion-builder-column-14>.fusion-column-wrapper {
										margin-right: 7.68%;
										margin-left: 7.68%;
									}
								}

								@media only screen and (max-width:640px) {
									.fusion-body .fusion-builder-column-14 {
										width: 100% !important;
										order: 0;
									}

									.fusion-builder-column-14>.fusion-column-wrapper {
										margin-right: 1.92%;
										margin-left: 1.92%;
									}
								}

							</style>
						</div>
						<style type="text/css">
							.fusion-body .fusion-flex-container.fusion-builder-row-4 {
								padding-top: 30px;
								margin-top: 0px;
								padding-right: 32px;
								padding-bottom: 60px;
								margin-bottom: 0px;
								padding-left: 32px;
							}

						</style>
					</div>
				</div>
			</div>
		</section>

	</div> <!-- fusion-row -->
</main> <!-- #main -->