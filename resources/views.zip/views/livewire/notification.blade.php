<section id="content" class="full-width">
    <div id="post-3275" class="post-3275 page type-page status-publish hentry">
        <span class="entry-title rich-snippet-hidden">Match Request Updates:</span><span class="vcard rich-snippet-hidden"><span
                class="fn"><a href="https://mysalafispouse.com/author/devsite/" title="Posts by H"
                    rel="author">H</a></span></span><span
            class="updated rich-snippet-hidden">2021-07-20T22:59:27+00:00</span>
        <div class="post-content">
            <div class="fusion-fullwidth fullwidth-box fusion-builder-row-3 fusion-flex-container nonhundred-percent-fullwidth non-hundred-percent-height-scrolling"
                style="background-color: #02427d;background-position: center center;background-repeat: no-repeat;border-width: 0px 0px 0px 0px;border-color:rgba(0,0,0,0.08);border-style:solid;">
                <div class="fusion-builder-row fusion-row fusion-flex-align-items-flex-start"
                    style="max-width:1372.8px;margin-left: calc(-4% / 2 );margin-right: calc(-4% / 2 );">
                    <div
                        class="fusion-layout-column fusion_builder_column fusion-builder-column-7 fusion_builder_column_1_1 1_1 fusion-flex-column">
                        <div class="fusion-column-wrapper fusion-flex-justify-content-flex-start fusion-content-layout-column"
                            style="background-position: left top; background-repeat: no-repeat; background-size: cover; padding: 0px; min-height: 0px;">
                            <style type="text/css">
                                @media only screen and (max-width:1024px) {
                                    .fusion-title.fusion-title-1 {
                                        margin-top: 0px !important;
                                        margin-bottom: 0px !important;
                                    }
                                }

                                @media only screen and (max-width:640px) {
                                    .fusion-title.fusion-title-1 {
                                        margin-top: 12px !important;
                                        margin-bottom: 24px !important;
                                    }
                                }

                            </style>
                            <div class="fusion-title title fusion-title-1 fusion-sep-none fusion-title-center fusion-title-text fusion-title-size-one fusion-border-below-title"
                                style="font-size:35px;margin-top:0px;margin-bottom:0px;">
                                <h1 class="title-heading-center fusion-responsive-typography-calculated"
                                    style="margin: 0px; font-size: 1em; color: rgb(255, 255, 255); --fontSize:35; line-height: 1.12;"
                                    data-fontsize="35" data-lineheight="39.2px"><i class="fa fa-envelope"></i> Match Request Updates:</h1>
                            </div>
                        </div>
                    </div>
                    <style type="text/css">
                        .fusion-body .fusion-builder-column-7 {
                            width: 100% !important;
                            margin-top: 0px;
                            margin-bottom: 0px;
                        }

                        .fusion-builder-column-7>.fusion-column-wrapper {
                            padding-top: 0 !important;
                            padding-right: 0px !important;
                            margin-right: 1.92%;
                            padding-bottom: 0 !important;
                            padding-left: 0px !important;
                            margin-left: 1.92%;
                        }

                        @media only screen and (max-width:1024px) {
                            .fusion-body .fusion-builder-column-7 {
                                width: 100% !important;
                                order: 0;
                            }

                            .fusion-builder-column-7>.fusion-column-wrapper {
                                margin-right: 1.92%;
                                margin-left: 1.92%;
                            }
                        }

                        @media only screen and (max-width:640px) {
                            .fusion-body .fusion-builder-column-7 {
                                width: 100% !important;
                                order: 0;
                            }

                            .fusion-builder-column-7>.fusion-column-wrapper {
                                margin-right: 1.92%;
                                margin-left: 1.92%;
                            }
                        }

                    </style>
                </div>
                <style type="text/css">
                    .fusion-body .fusion-flex-container.fusion-builder-row-3 {
                        padding-top: 25px;
                        margin-top: 0;
                        padding-right: 32px;
                        padding-bottom: 25px;
                        margin-bottom: 0;
                        padding-left: 32px;
                    }

                </style>
            </div>
            {{-- <div class="fusion-fullwidth fullwidth-box fusion-builder-row-4 fusion-flex-container nonhundred-percent-fullwidth non-hundred-percent-height-scrolling"
                style="background-color: rgba(255,255,255,0);background-position: center center;background-repeat: no-repeat;border-width: 0px 0px 0px 0px;border-color:rgba(0,0,0,0.08);border-style:solid;"> --}}
            <div class="fusion-builder-row fusion-row fusion-flex-align-items-flex-start"
                style="max-width:1372.8px;margin-left: calc(-4% / 2 );margin-right: calc(-4% / 2 );">
                <div
                    class="fusion-layout-column fusion_builder_column fusion-builder-column-8 fusion_builder_column_1_1 1_1 fusion-flex-column fusion-flex-align-self-center">
                    <div class="fusion-column-wrapper fusion-flex-justify-content-center fusion-content-layout-column"
                        style="background-position: left top; background-repeat: no-repeat; background-size: cover; padding: 0px; min-height: 0px;">
                        <style type="text/css">
                            @media only screen and (max-width:1024px) {
                                .fusion-title.fusion-title-2 {
                                    margin-top: 12px !important;
                                    margin-bottom: 24px !important;
                                }
                            }

                            @media only screen and (max-width:640px) {
                                .fusion-title.fusion-title-2 {
                                    margin-top: 12px !important;
                                    margin-bottom: 24px !important;
                                }
                            }

                        </style>

                    </div>
                </div>
                <style type="text/css">
                    .fusion-body .fusion-builder-column-8 {
                        width: 100% !important;
                        margin-top: 20px;
                        margin-bottom: 20px;
                    }

                    .fusion-builder-column-8>.fusion-column-wrapper {
                        padding-top: 0px !important;
                        padding-right: 0px !important;
                        margin-right: 1.92%;
                        padding-bottom: 0px !important;
                        padding-left: 0px !important;
                        margin-left: 1.92%;
                    }

                    @media only screen and (max-width:1024px) {
                        .fusion-body .fusion-builder-column-8 {
                            width: 100% !important;
                            order: 0;
                        }

                        .fusion-builder-column-8>.fusion-column-wrapper {
                            margin-right: 1.92%;
                            margin-left: 1.92%;
                        }
                    }

                    @media only screen and (max-width:640px) {
                        .fusion-body .fusion-builder-column-8 {
                            width: 100% !important;
                            order: 0;
                        }

                        .fusion-builder-column-8>.fusion-column-wrapper {
                            margin-right: 1.92%;
                            margin-left: 1.92%;
                        }
                    }

                </style>
            </div>
            <style type="text/css">
                .fusion-body .fusion-flex-container.fusion-builder-row-4 {
                    padding-top: 50px;
                    margin-top: 0px;
                    padding-right: 32px;
                    padding-bottom: 40px;
                    margin-bottom: 0px;
                    padding-left: 32px;
                }

            </style>
            {{-- </div> --}}
            <div class="fusion-fullwidth fullwidth-box fusion-builder-row-5 fusion-flex-container nonhundred-percent-fullwidth non-hundred-percent-height-scrolling"
                style="background-color: rgba(255,255,255,0);background-position: center center;background-repeat: no-repeat;border-width: 0px 0px 0px 0px;border-color:rgba(0,0,0,0.08);border-style:solid;">
                <div class="fusion-builder-row fusion-row fusion-flex-align-items-flex-start"
                    style="max-width:1372.8px;margin-left: calc(-4% / 2 );margin-right: calc(-4% / 2 );">
                    <div
                        class="fusion-layout-column fusion_builder_column fusion-builder-column-9 fusion_builder_column_1_5 1_5 fusion-flex-column">
                        <div class="fusion-column-wrapper fusion-flex-justify-content-flex-start fusion-content-layout-column"
                            style="background-position:left top;background-repeat:no-repeat;-webkit-background-size:cover;-moz-background-size:cover;-o-background-size:cover;background-size:cover;padding: 0px 0px 0px 0px;">
                        </div>
                    </div>
                    <style type="text/css">
                        .fusion-body .fusion-builder-column-9 {
                            width: 20% !important;
                            margin-top: 20px;
                            margin-bottom: 20px;
                        }

                        .fusion-builder-column-9>.fusion-column-wrapper {
                            padding-top: 0px !important;
                            padding-right: 0px !important;
                            margin-right: 9.6%;
                            padding-bottom: 0px !important;
                            padding-left: 0px !important;
                            margin-left: 9.6%;
                        }

                        @media only screen and (max-width:1024px) {
                            .fusion-body .fusion-builder-column-9 {
                                width: 20% !important;
                                order: 0;
                            }

                            .fusion-builder-column-9>.fusion-column-wrapper {
                                margin-right: 9.6%;
                                margin-left: 9.6%;
                            }
                        }

                        @media only screen and (max-width:640px) {
                            .fusion-body .fusion-builder-column-9 {
                                width: 100% !important;
                                order: 0;
                            }

                            .fusion-builder-column-9>.fusion-column-wrapper {
                                margin-right: 1.92%;
                                margin-left: 1.92%;
                            }
                        }
                    </style>
                    <style>
                        th,
                        td {
                            padding: 15px;
                            border: 1px solid;
                        }
                    </style>
                    <div style="overflow-x:auto;">
                        <table style="width: 100%;" border="1px solid;" cellpadding="10">
                            <tr>
                                <th>Order:</th>
                                <th>Subject:</th>
                                <th>
                                <div>
                                    <span>Message</span><span style="padding-left:10px;"><i class="fa fa-envelope"></i></span>    
                                </div>    
                                </th>
                                <th>Profile Link</th>
                                <th>Date & Time</th>
                            </tr>
                            @php $sr = 1; @endphp
                            @foreach($emails as $item)
                            <tr>
                                <td>{{ $sr++ }}</td>
                                <td>{{ $item->type }}</td>
                                <td>{!! $item->message !!}</td>
                                <td><a style="color:#224794;" target="blank" href="{{ $item->profile_link }}">See Profile</a></td>
                                <td>{{ $item->created_at->diffForHumans(); }}</td>
                            </tr>
                            @endforeach
                        </table>
                        <br>
                        <br>
                        
                    </div>

                    <style type="text/css">
                        .fusion-body .fusion-builder-column-10 {
                            width: 60% !important;
                            margin-top: 20px;
                            margin-bottom: 20px;
                        }

                        .fusion-builder-column-10>.fusion-column-wrapper {
                            padding-top: 0px !important;
                            padding-right: 0px !important;
                            margin-right: 3.2%;
                            padding-bottom: 0px !important;
                            padding-left: 0px !important;
                            margin-left: 3.2%;
                        }

                        @media only screen and (max-width:1024px) {
                            .fusion-body .fusion-builder-column-10 {
                                width: 60% !important;
                                order: 0;
                            }

                            .fusion-builder-column-10>.fusion-column-wrapper {
                                margin-right: 3.2%;
                                margin-left: 3.2%;
                            }
                        }

                        @media only screen and (max-width:640px) {
                            .fusion-body .fusion-builder-column-10 {
                                width: 100% !important;
                                order: 0;
                            }

                            .fusion-builder-column-10>.fusion-column-wrapper {
                                margin-right: 1.92%;
                                margin-left: 1.92%;
                            }
                        }

                    </style>

                    <style type="text/css">
                        .fusion-body .fusion-builder-column-11 {
                            width: 20% !important;
                            margin-top: 20px;
                            margin-bottom: 20px;
                        }

                        .fusion-builder-column-11>.fusion-column-wrapper {
                            padding-top: 0px !important;
                            padding-right: 0px !important;
                            margin-right: 9.6%;
                            padding-bottom: 0px !important;
                            padding-left: 0px !important;
                            margin-left: 9.6%;
                        }

                        @media only screen and (max-width:1024px) {
                            .fusion-body .fusion-builder-column-11 {
                                width: 20% !important;
                                order: 0;
                            }

                            .fusion-builder-column-11>.fusion-column-wrapper {
                                margin-right: 9.6%;
                                margin-left: 9.6%;
                            }
                        }

                        @media only screen and (max-width:640px) {
                            .fusion-body .fusion-builder-column-11 {
                                width: 100% !important;
                                order: 0;
                            }

                            .fusion-builder-column-11>.fusion-column-wrapper {
                                margin-right: 1.92%;
                                margin-left: 1.92%;
                            }
                        }

                    </style>
                </div>
                <style type="text/css">
                    .fusion-body .fusion-flex-container.fusion-builder-row-5 {
                        padding-top: 0px;
                        margin-top: 0px;
                        padding-right: 32px;
                        padding-bottom: 0px;
                        margin-bottom: 0px;
                        padding-left: 32px;
                    }

                </style>
            </div>
        </div>
    </div>
</section>
