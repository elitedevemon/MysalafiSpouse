<main class="clearfix width-100">
    <div class="fusion-row" style="max-width:100%;">
        <section id="content" class="full-width">
            <div id="post-18" class="post-18 page type-page status-publish hentry">

                <div class="post-content">
                    <div class="fusion-fullwidth fullwidth-box fusion-builder-row-3 fusion-flex-container hundred-percent-fullwidth non-hundred-percent-height-scrolling"
                        style="background-color: #02427d;background-position: center center;background-repeat: no-repeat;border-width: 0px 0px 0px 0px;border-color:rgba(0,0,0,0.08);border-style:solid;">
                        <div class="fusion-builder-row fusion-row fusion-flex-align-items-flex-start"
                            style="width:104% !important;max-width:104% !important;margin-left: calc(-4% / 2 );margin-right: calc(-4% / 2 );">
                            <div
                                class="fusion-layout-column fusion_builder_column fusion-builder-column-7 fusion_builder_column_1_1 1_1 fusion-flex-column">
                                <div class="fusion-column-wrapper fusion-flex-justify-content-flex-start fusion-content-layout-column"
                                    style="background-position:left top;background-repeat:no-repeat;-webkit-background-size:cover;-moz-background-size:cover;-o-background-size:cover;background-size:cover;padding: 0px 0px 0px 0px;">
                                    <style type="text/css">
                                        @media only screen and (max-width:1024px) {
                                            .fusion-title.fusion-title-1 {
                                                margin-top: 12px !important;
                                                margin-bottom: 24px !important;
                                            }
                                        }

                                        @media only screen and (max-width:640px) {
                                            .fusion-title.fusion-title-1 {
                                                margin-top: 12px !important;
                                                margin-bottom: 24px !important;
                                            }
                                        }

                                    </style>
                                    <div class="fusion-title title fusion-title-1 fusion-sep-none fusion-title-center fusion-title-text fusion-title-size-one"
                                        style="font-size:30px;margin-top:12px;margin-bottom:24px;">
                                        <h1 class="title-heading-center" style="margin:0;font-size:1em;color:#ffffff;">
                                            SEE ALL PROFILES
                                        </h1>
                                    </div>
                                </div>
                            </div>
                            <style type="text/css">
                                .fusion-body .fusion-builder-column-7 {
                                    width: 100% !important;
                                    margin-top: 20px;
                                    margin-bottom: 0px;
                                }

                                .fusion-builder-column-7>.fusion-column-wrapper {
                                    padding-top: 0px !important;
                                    padding-right: 0px !important;
                                    margin-right: 1.92%;
                                    padding-bottom: 0px !important;
                                    padding-left: 0px !important;
                                    margin-left: 1.92%;
                                }

                                @media only screen and (max-width:1024px) {
                                    .fusion-body .fusion-builder-column-7 {
                                        width: 100% !important;
                                        order: 0;
                                    }

                                    .fusion-builder-column-7>.fusion-column-wrapper {
                                        margin-right: 1.92%;
                                        margin-left: 1.92%;
                                    }
                                }

                                @media only screen and (max-width:640px) {
                                    .fusion-body .fusion-builder-column-7 {
                                        width: 100% !important;
                                        order: 0;
                                    }

                                    .fusion-builder-column-7>.fusion-column-wrapper {
                                        margin-right: 1.92%;
                                        margin-left: 1.92%;
                                    }
                                }

                            </style>
                        </div>
                        <style type="text/css">
                            .fusion-body .fusion-flex-container.fusion-builder-row-3 {
                                padding-top: 20px;
                                margin-top: 0px;
                                padding-right: 32px;
                                padding-bottom: 20px;
                                margin-bottom: 0px;
                                padding-left: 32px;
                            }

                        </style>
                    </div>
                    <div class="fusion-fullwidth fullwidth-box fusion-builder-row-4 fusion-flex-container nonhundred-percent-fullwidth non-hundred-percent-height-scrolling"
                        style="background-color: rgba(255,255,255,0);background-position: center center;background-repeat: no-repeat;border-width: 0px 0px 0px 0px;border-color:rgba(0,0,0,0.08);border-style:solid;">
                        <div class="fusion-builder-row fusion-row fusion-flex-align-items-flex-start"
                            style="max-width:1372.8px;margin-left: calc(-4% / 2 );margin-right: calc(-4% / 2 );">
                            <div
                                class="fusion-layout-column fusion_builder_column fusion-builder-column-8 fusion_builder_column_1_1 1_1 fusion-flex-column">
                                <div class="fusion-column-wrapper fusion-flex-justify-content-flex-start fusion-content-layout-column"
                                    style="background-position:left top;background-repeat:no-repeat;-webkit-background-size:cover;-moz-background-size:cover;-o-background-size:cover;background-size:cover;padding: 0px 0px 0px 0px;">
                                    <style type="text/css">
                                        @media only screen and (max-width:1024px) {
                                            .fusion-title.fusion-title-2 {
                                                margin-top: 12px !important;
                                                margin-bottom: 24px !important;
                                            }
                                        }

                                        @media only screen and (max-width:640px) {
                                            .fusion-title.fusion-title-2 {
                                                margin-top: 12px !important;
                                                margin-bottom: 24px !important;
                                            }
                                        }

                                    </style>
                                    <div class="fusion-title title fusion-title-2 fusion-sep-none fusion-title-center fusion-title-text fusion-title-size-one"
                                        style="font-size:30px;margin-top:12px;margin-bottom:24px;">
                                        <h1 class="title-heading-center"
                                            style="font-family:&quot;Poppins&quot;;font-weight:500;margin:0;font-size:1em;color:#303030;">
                                            WHO ARE OUR APPLICANTS?</h1>
                                    </div>
                                    <div class="fusion-text fusion-text-1" style="line-height:1.8em;">
                                        <p style="text-align: center;">The MySalafiSpouse matchmaking
                                            service is designed for orthodox Muslims worldwide. Any Muslim
                                            who adheres to the Sunnah can apply! We currently have a growing
                                            database of 500+ applicants worldwide and we have successfully
                                            matched over 250 applicants. Our applicants are <span
                                                style="background-color: rgba(255, 255, 255, 0); color: var(--body_typography-color); font-family: var(--body_typography-font-family); font-size: var(--body_typography-font-size); font-style: var(--body_typography-font-style,normal); letter-spacing: var(--body_typography-letter-spacing);">brothers
                                                and sisters based in the UK and internationally, in over 30
                                            </span><span
                                                style="color: var(--body_typography-color); font-family: var(--body_typography-font-family); font-size: var(--body_typography-font-size); font-style: var(--body_typography-font-style,normal); letter-spacing: var(--body_typography-letter-spacing); background-color: rgba(255, 255, 255, 0);">different
                                                countries, including the USA, India and Saudi Arabia.</span>
                                        </p>
                                    </div>
                                    <div style="text-align:center;">
                                        <style type="text/css">
                                            .fusion-button.button-1 .fusion-button-text,
                                            .fusion-button.button-1 i {
                                                color: #ffffff;
                                            }

                                            .fusion-button.button-1 .fusion-button-icon-divider {
                                                border-color: #ffffff;
                                            }

                                            .fusion-button.button-1:hover .fusion-button-text,
                                            .fusion-button.button-1:hover i,
                                            .fusion-button.button-1:focus .fusion-button-text,
                                            .fusion-button.button-1:focus i,
                                            .fusion-button.button-1:active .fusion-button-text,
                                            .fusion-button.button-1:active {
                                                color: #ffffff;
                                            }

                                            .fusion-button.button-1:hover .fusion-button-icon-divider,
                                            .fusion-button.button-1:hover .fusion-button-icon-divider,
                                            .fusion-button.button-1:active .fusion-button-icon-divider {
                                                border-color: #ffffff;
                                            }

                                            .fusion-button.button-1:hover,
                                            .fusion-button.button-1:focus,
                                            .fusion-button.button-1:active {
                                                border-color: #ffffff;
                                            }

                                            .fusion-button.button-1 {
                                                border-color: #ffffff;
                                                border-radius: 3px;
                                            }

                                            .fusion-button.button-1 {
                                                background: #224794;
                                            }

                                            .fusion-button.button-1:hover,
                                            .button-1:focus,
                                            .fusion-button.button-1:active {
                                                background: #dd1922;
                                            }

                                        </style><a
                                            class="fusion-button button-flat button-xlarge button-custom button-1 fusion-button-default-span "
                                            target="_self" href="#"><span class="fusion-button-text">Submit
                                                Your Profile! </span></a>
                                    </div>
                                    <style>
                                        div.gallery {
                                            margin: 5px;
                                            /* border: 1px solid #ccc; */
                                            float: left;
                                            width: 410px;
                                        }

                                        div.gallery:hover {
                                            border: 1px solid #777;
                                        }

                                        div.gallery img {
                                            width: 100%;
                                            height: auto;
                                        }

                                        div.desc {
                                            padding: 15px;
                                            text-align: center;
                                        }
										

                                    </style>
                                    <div class="fusion-text fusion-text-1" style="line-height:1.8em;">
                                        <br>
                                        <br>
										@foreach($post as $item)
										@foreach($item as $utem)
										@if(isset($utem['media_url']))
											@if($utem['media_url'])
                                        <div class="gallery">
											
                                            <a target="_blank" href="{{ $utem['permalink'] ?? '' }}" >
                                                {{-- <img src="{{ $utem['media_url'] ?? '' }} alt="Cinque Terre" width="600" height="400"> --}}
											
													<img  src="{{  $utem['media_url'] }}" alt="{{ $utem['caption'] ?? '' }}">
												
                                            </a>
										
                                            {{-- <div class="desc">Add a description of the image here</div> --}}
                                        </div>
										@endif
										@endif
										@endforeach
										@endforeach
                                        
                                    </div>




                                    <div class="fusion-separator fusion-full-width-sep"
                                        style="align-self: center;margin-left: auto;margin-right: auto;margin-top:50px;width:100%;">
                                    </div>

                                </div>
                            </div>
                            <style type="text/css">
                                .fusion-body .fusion-builder-column-8 {
                                    width: 100% !important;
                                    margin-top: 20px;
                                    margin-bottom: 20px;
                                }

                                .fusion-builder-column-8>.fusion-column-wrapper {
                                    padding-top: 0px !important;
                                    padding-right: 0px !important;
                                    margin-right: 1.92%;
                                    padding-bottom: 0px !important;
                                    padding-left: 0px !important;
                                    margin-left: 1.92%;
                                }

                                @media only screen and (max-width:1024px) {
                                    .fusion-body .fusion-builder-column-8 {
                                        width: 100% !important;
                                        order: 0;
                                    }

                                    .fusion-builder-column-8>.fusion-column-wrapper {
                                        margin-right: 1.92%;
                                        margin-left: 1.92%;
                                    }
                                }

                                @media only screen and (max-width:640px) {
                                    .fusion-body .fusion-builder-column-8 {
                                        width: 100% !important;
                                        order: 0;
                                    }

                                    .fusion-builder-column-8>.fusion-column-wrapper {
                                        margin-right: 1.92%;
                                        margin-left: 1.92%;
                                    }
                                }

                            </style>
                        </div>
                        <style type="text/css">
                            .fusion-body .fusion-flex-container.fusion-builder-row-4 {
                                padding-top: 100px;
                                margin-top: 0px;
                                padding-right: 32px;
                                padding-bottom: 100px;
                                margin-bottom: 0px;
                                padding-left: 32px;
                            }

                        </style>
                    </div>
                </div>
            </div>
        </section>

    </div> <!-- fusion-row -->
</main>
