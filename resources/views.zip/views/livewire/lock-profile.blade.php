<section id="content" class="full-width">
    <div id="post-3275" class="post-3275 page type-page status-publish hentry">
        <span class="entry-title rich-snippet-hidden">Login!</span><span class="vcard rich-snippet-hidden"><span
                class="fn"><a href="https://mysalafispouse.com/author/devsite/" title="Posts by H"
                    rel="author">H</a></span></span><span
            class="updated rich-snippet-hidden">2021-07-20T22:59:27+00:00</span>
        <div class="post-content">
            <div class="fusion-fullwidth fullwidth-box fusion-builder-row-3 fusion-flex-container nonhundred-percent-fullwidth non-hundred-percent-height-scrolling"
                style="background-color: #02427d;background-position: center center;background-repeat: no-repeat;border-width: 0px 0px 0px 0px;border-color:rgba(0,0,0,0.08);border-style:solid;">
                <div class="fusion-builder-row fusion-row fusion-flex-align-items-flex-start"
                    style="max-width:1372.8px;margin-left: calc(-4% / 2 );margin-right: calc(-4% / 2 );">
                    <div
                        class="fusion-layout-column fusion_builder_column fusion-builder-column-7 fusion_builder_column_1_1 1_1 fusion-flex-column">
                        <div class="fusion-column-wrapper fusion-flex-justify-content-flex-start fusion-content-layout-column"
                            style="background-position: left top; background-repeat: no-repeat; background-size: cover; padding: 0px; min-height: 0px;">
                            <style type="text/css">
                                @media only screen and (max-width:1024px) {
                                    .fusion-title.fusion-title-1 {
                                        margin-top: 0px !important;
                                        margin-bottom: 0px !important;
                                    }
                                }

                                @media only screen and (max-width:640px) {
                                    .fusion-title.fusion-title-1 {
                                        margin-top: 12px !important;
                                        margin-bottom: 24px !important;
                                    }
                                }

                            </style>
                            <div class="fusion-title title fusion-title-1 fusion-sep-none fusion-title-center fusion-title-text fusion-title-size-one fusion-border-below-title"
                                style="font-size:35px;margin-top:0px;margin-bottom:0px;">
                                <h1 class="title-heading-center fusion-responsive-typography-calculated"
                                    style="margin: 0px; font-size: 1em; color: rgb(255, 255, 255); --fontSize:35; line-height: 1.12;"
                                    data-fontsize="35" data-lineheight="39.2px">Profile Locked</h1>
                            </div>
                        </div>
                    </div>
                    <style type="text/css">
                        .fusion-body .fusion-builder-column-7 {
                            width: 100% !important;
                            margin-top: 0px;
                            margin-bottom: 0px;
                        }

                        .fusion-builder-column-7>.fusion-column-wrapper {
                            padding-top: 0 !important;
                            padding-right: 0px !important;
                            margin-right: 1.92%;
                            padding-bottom: 0 !important;
                            padding-left: 0px !important;
                            margin-left: 1.92%;
                        }

                        @media only screen and (max-width:1024px) {
                            .fusion-body .fusion-builder-column-7 {
                                width: 100% !important;
                                order: 0;
                            }

                            .fusion-builder-column-7>.fusion-column-wrapper {
                                margin-right: 1.92%;
                                margin-left: 1.92%;
                            }
                        }

                        @media only screen and (max-width:640px) {
                            .fusion-body .fusion-builder-column-7 {
                                width: 100% !important;
                                order: 0;
                            }

                            .fusion-builder-column-7>.fusion-column-wrapper {
                                margin-right: 1.92%;
                                margin-left: 1.92%;
                            }
                        }

                    </style>
                </div>
                <style type="text/css">
                    .fusion-body .fusion-flex-container.fusion-builder-row-3 {
                        padding-top: 25px;
                        margin-top: 0;
                        padding-right: 32px;
                        padding-bottom: 25px;
                        margin-bottom: 0;
                        padding-left: 32px;
                    }

                </style>
            </div>
            {{-- <div class="fusion-fullwidth fullwidth-box fusion-builder-row-4 fusion-flex-container nonhundred-percent-fullwidth non-hundred-percent-height-scrolling"
                style="background-color: rgba(255,255,255,0);background-position: center center;background-repeat: no-repeat;border-width: 0px 0px 0px 0px;border-color:rgba(0,0,0,0.08);border-style:solid;"> --}}
            <div class="fusion-builder-row fusion-row fusion-flex-align-items-flex-start"
                style="max-width:1372.8px;margin-left: calc(-4% / 2 );margin-right: calc(-4% / 2 );">
                <div
                    class="fusion-layout-column fusion_builder_column fusion-builder-column-8 fusion_builder_column_1_1 1_1 fusion-flex-column fusion-flex-align-self-center">
                    <div class="fusion-column-wrapper fusion-flex-justify-content-center fusion-content-layout-column"
                        style="background-position: left top; background-repeat: no-repeat; background-size: cover; padding: 0px; min-height: 0px;">
                        <style type="text/css">
                            @media only screen and (max-width:1024px) {
                                .fusion-title.fusion-title-2 {
                                    margin-top: 12px !important;
                                    margin-bottom: 24px !important;
                                }
                            }

                            @media only screen and (max-width:640px) {
                                .fusion-title.fusion-title-2 {
                                    margin-top: 12px !important;
                                    margin-bottom: 24px !important;
                                }
                            }

                        </style>

                    </div>
                </div>
                <style type="text/css">
                    .fusion-body .fusion-builder-column-8 {
                        width: 100% !important;
                        margin-top: 20px;
                        margin-bottom: 20px;
                    }

                    .fusion-builder-column-8>.fusion-column-wrapper {
                        padding-top: 0px !important;
                        padding-right: 0px !important;
                        margin-right: 1.92%;
                        padding-bottom: 0px !important;
                        padding-left: 0px !important;
                        margin-left: 1.92%;
                    }

                    @media only screen and (max-width:1024px) {
                        .fusion-body .fusion-builder-column-8 {
                            width: 100% !important;
                            order: 0;
                        }

                        .fusion-builder-column-8>.fusion-column-wrapper {
                            margin-right: 1.92%;
                            margin-left: 1.92%;
                        }
                    }

                    @media only screen and (max-width:640px) {
                        .fusion-body .fusion-builder-column-8 {
                            width: 100% !important;
                            order: 0;
                        }

                        .fusion-builder-column-8>.fusion-column-wrapper {
                            margin-right: 1.92%;
                            margin-left: 1.92%;
                        }
                    }

                </style>
            </div>
            <style type="text/css">
                .fusion-body .fusion-flex-container.fusion-builder-row-4 {
                    padding-top: 50px;
                    margin-top: 0px;
                    padding-right: 32px;
                    padding-bottom: 40px;
                    margin-bottom: 0px;
                    padding-left: 32px;
                }

            </style>
            {{-- </div> --}}
            <div class="fusion-fullwidth fullwidth-box fusion-builder-row-5 fusion-flex-container nonhundred-percent-fullwidth non-hundred-percent-height-scrolling"
                style="background-color: rgba(255,255,255,0);background-position: center center;background-repeat: no-repeat;border-width: 0px 0px 0px 0px;border-color:rgba(0,0,0,0.08);border-style:solid;">
                <div class="fusion-builder-row fusion-row fusion-flex-align-items-flex-start"
                    style="max-width:1372.8px;margin-left: calc(-4% / 2 );margin-right: calc(-4% / 2 );">
                    <div
                        class="fusion-layout-column fusion_builder_column fusion-builder-column-9 fusion_builder_column_1_5 1_5 fusion-flex-column">
                        <div class="fusion-column-wrapper fusion-flex-justify-content-flex-start fusion-content-layout-column"
                            style="background-position:left top;background-repeat:no-repeat;-webkit-background-size:cover;-moz-background-size:cover;-o-background-size:cover;background-size:cover;padding: 0px 0px 0px 0px;">
                        </div>
                    </div>
                    <style type="text/css">
                        .fusion-body .fusion-builder-column-9 {
                            width: 20% !important;
                            margin-top: 20px;
                            margin-bottom: 20px;
                        }

                        .fusion-builder-column-9>.fusion-column-wrapper {
                            padding-top: 0px !important;
                            padding-right: 0px !important;
                            margin-right: 9.6%;
                            padding-bottom: 0px !important;
                            padding-left: 0px !important;
                            margin-left: 9.6%;
                        }

                        @media only screen and (max-width:1024px) {
                            .fusion-body .fusion-builder-column-9 {
                                width: 20% !important;
                                order: 0;
                            }

                            .fusion-builder-column-9>.fusion-column-wrapper {
                                margin-right: 9.6%;
                                margin-left: 9.6%;
                            }
                        }

                        @media only screen and (max-width:640px) {
                            .fusion-body .fusion-builder-column-9 {
                                width: 100% !important;
                                order: 0;
                            }

                            .fusion-builder-column-9>.fusion-column-wrapper {
                                margin-right: 1.92%;
                                margin-left: 1.92%;
                            }
                        }

                    </style>
                    <div
                        class="fusion-layout-column fusion_builder_column fusion-builder-column-10 fusion_builder_column_3_5 3_5 fusion-flex-column">
                        <div class="fusion-column-wrapper fusion-flex-justify-content-flex-start fusion-content-layout-column"
                            style="background-position: left top; background-repeat: no-repeat; background-size: cover; padding: 0px; min-height: 0px;">
                            <div class="fusion-text fusion-text-1">
                                <link rel="stylesheet" property="stylesheet"
                                    href="https://mysalafispouse.com/wp-content/plugins/happyforms-upgrade/inc/assets/css/frontend/layout.css?ver=1.18.4">
                                <link rel="stylesheet" property="stylesheet"
                                    href="https://mysalafispouse.com/wp-content/plugins/happyforms-upgrade/inc/assets/css/frontend/color.css?ver=1.18.4">
                                <link rel="stylesheet" property="stylesheet"
                                    href="https://mysalafispouse.com/wp-content/plugins/happyforms-upgrade/inc/assets/css/frontend/poll.css?1.18.4">
                                <link rel="stylesheet" property="stylesheet"
                                    href="https://mysalafispouse.com/wp-content/plugins/happyforms-upgrade/integrations/assets/css/frontend/payments.css?1.18.4">
                                <!-- HappyForms CSS variables -->
                                <style>
                                    #happyforms-3443 {
                                        --happyforms-form-width: 100%;
                                        --happyforms-form-title-font-size: 32px;
                                        --happyforms-part-title-font-size: 16px;
                                        --happyforms-part-description-font-size: 14px;
                                        --happyforms-part-value-font-size: 16px;
                                        --happyforms-submit-button-font-size: 16px;
                                        --happyforms-color-primary: #000000;
                                        --happyforms-color-success-notice: #ebf9f0;
                                        --happyforms-color-success-notice-text: #1eb452;
                                        --happyforms-color-error: #f23000;
                                        --happyforms-color-error-notice: #ffeeea;
                                        --happyforms-color-error-notice-text: #f23000;
                                        --happyforms-color-part-title: #000000;
                                        --happyforms-color-part-value: #000000;
                                        --happyforms-color-part-placeholder: #888888;
                                        --happyforms-color-part-description: #454545;
                                        --happyforms-color-part-border: #dbdbdb;
                                        --happyforms-color-part-border-focus: #7aa4ff;
                                        --happyforms-color-part-background: #ffffff;
                                        --happyforms-color-part-background-focus: #ffffff;
                                        --happyforms-color-submit-background: #000000;
                                        --happyforms-color-submit-background-hover: #000000;
                                        --happyforms-color-submit-border: transparent;
                                        --happyforms-color-submit-text: #ffffff;
                                        --happyforms-color-submit-text-hover: #ffffff;
                                        --happyforms-color-rating: #cccccc;
                                        --happyforms-color-rating-hover: #ffbf00;
                                        --happyforms-color-table-row-odd: #fcfcfc;
                                        --happyforms-color-table-row-even: #efefef;
                                        --happyforms-color-table-row-odd-text: #000000;
                                        --happyforms-color-table-row-even-text: #000000;
                                        --happyforms-color-divider-hr: #cccccc;
                                        --happyforms-color-choice-checkmark-bg: #000000;
                                        --happyforms-color-choice-checkmark-bg-focus: #16bc00;
                                        --happyforms-color-choice-checkmark-color: #ffffff;
                                        --happyforms-color-dropdown-item-bg: #ffffff;
                                        --happyforms-color-dropdown-item-text: #000000;
                                        --happyforms-color-dropdown-item-bg-hover: #f4f4f5;
                                        --happyforms-color-dropdown-item-text-hover: #000000;
                                        --happyforms-color-progress-bar-primary: #e6e6e6;
                                        --happyforms-color-progress-bar-primary-bg: #ffffff;
                                        --happyforms-color-progress-bar-secondary: #000000;
                                        --happyforms-color-progress-bar-text-primary: #ABABAB;
                                        --happyforms-color-progress-bar-text-secondary: #ffffff;
                                        --happyforms-color-multistep-previous-background: #dfdfdf;
                                        --happyforms-color-multistep-previous-background-hover: #cdcdcd;
                                        --happyforms-color-multistep-previous-text: #000000;
                                        --happyforms-color-multistep-previous-text-hover: #000000;
                                        --happyforms-poll-bar-color: #e8e8e8;
                                        --happyforms-poll-link-color: #000000;
                                        --happyforms-poll-winner-color: #000000;
                                    }

                                </style>
                                <!-- End of HappyForms CSS variables -->
                                <div class="happyforms-form happyforms-styles happyforms-form--hide-title happyforms-form--submit-button-border-radius-pill happyforms-form--submit-button-fullwidth"
                                    id="happyforms-3443">
                                    <h3 class="happyforms-form__title fusion-responsive-typography-calculated"
                                        data-fontsize="32" data-lineheight="40.32px"
                                        style="--fontSize:32; line-height: 1.26;">Login</h3>
                                    <div class="happyforms-flex">
                                        @error('credentials')
                                        <div
                                            style="text-align: center;width:100%;background:#ffc4c4;color:red;padding:10px;border-radius:10px;">
                                            {{ $message }}
                                        </div>
                                        @enderror
                                        @if(session('message'))
                                        <div class="col-md-12" style="padding-left: 0px;">
                                            <div class="alert alert-success">
                                                {!!session('message')!!}
                                                {{-- asda --}}
                                            </div>
                                        </div>
                                        @endif
                                        @if(session('garammessage'))
                                        <div class="col-md-12" style="padding-left: 0px;">
                                            <div class="alert alert-danger">
                                                {!!session('garammessage')!!}
                                                {{-- asda --}}
                                            </div>
                                        </div>
                                        @endif
                                        @if(session('thandamessage'))
                                        <div class="col-md-12" style="padding-left: 0px;">
                                            <div class="alert alert-warning">
                                                {!!session('thandamessage')!!}
                                                {{-- asda --}}
                                            </div>
                                        </div>
                                        @endif
                                        @if(!session('message') && !session('thandamessage'))
                                        <div class="col-md-12" style="padding-left: 0px;padding-right: 0px;">
                                            <p>If yes, please select your payment method below:</p>
                                        </div>
                                        <div class="col-md-12" style="padding-left: 5px;padding-right: 5px;">
                                            {{-- <label for="">Payment mode</label> --}}
                                            <select wire:model="type" id=""
                                                style="width: 100%;padding-left:10px;height: 46px;border-radius: 5px;">
                                                <option value="" hidden>Select</option>
                                                @if($user->type == 'International')
                                                {{-- <option value="stripe">Stripe</option> --}}
                                                <option value="paypal">Paypal</option>
                                                @endif
                                                <option value="other">Bank Transfer</option>
                                            </select>
                                        </div>
                                        @if($type=='other')
                                        <div class="col-md-8">
                                            <br>
                                            @if(Auth::user()->type == "UK Base")
                                            <p><b>UK Bank Transfer ( £10 GBP)</b></p>
                                            @else
                                            <p><b>  <p><b>Western Union Transfer ( £10 GBP)</b></p></b></p>
                                            @endif
                                            @if($user->type != 'UK Base')

                                            {{-- <br> --}}
                                            {{-- <p><b>Account name:</b> {{ $config->bank_western }}</p>
                                            <p><b>Branch/Bank Name</b> {{ $config->bracnh_name }}</p>
                                            <p><b>IBAN/SWIFT or others</b> {{ $config->iban }}</p> --}}
                                            <p><b>Account name:</b> MR HAIDER RAZAQ</p>
                    <p><b>Account Number:</b> 87757629</p>
                    <p><b>Sort Code:</b> 09-01-28</p>
                    <p><b>Bank:</b> SANTANDER (UK)</p>
                                            <p>MTCN Number</p>
                                            <input type="text" wire:model="mtn_no"
                                                style="width: 100%;height: 30px;border-radius: 0px;padding-left: 11px;border-color:#224794;"
                                                placeholder="MTCN Number">
                                            @error('mtn_no')
                                            <span style="color: red">MTCN Number is required</span>
                                            @enderror
                                            @else
                                            <p><b>Account name:</b> H Razaq</p>
                                            <p><b>Sort code:</b> 04-00-04</p>
                                            <p><b>Account number:</b> 03970943</p>
                                            <p><b>Bank:</b> Monzo (UK)</p>
                                            @endif


                                            <br>
                                            <br>
                                            <p>Attach Payment Screenshot (Optional)</p>
                                            <input type="file" wire:model="evidence"
                                                style="width: 100%;height: 30px;border-radius: 0px;padding-left: 0px;border-color:#224794;"
                                                placeholder="Evidence">
                                            @error('evidence')
                                            <span style="color: red">{{ $message }}</span>
                                            @enderror
                                            {{-- <br>
                                            <p>Date</p>
                                            <input type="date" style="width: 100%;height: 30px;border-radius: 0px;padding-left: 11px;border-color:#224794;" placeholder="MTCN Number"> --}}
                                        </div>
                                        @endif
                                        @if($type == 'paypal')
                <div class="col-md-8">
                    <br>
                    {{-- <p><b>Paypal link</b></p> --}}
                    <div style="text-align: center;">
                        <p><b style="text-align:center;">Anual Fee
                            @if(Auth::user()->type == 'UK Base')
                            £{{$config->anual_fee_euro}} @else ${{$config->anual_fee}} @endif 
                            Pay through our PayPal link below:
                        </b></p>
                    </div>
                    @if($user->type != 'UK Base')
                    <div style="text-align: center;">
                            
                        <u><a target="blank" style="color:blue;text-align:center;" href="https://www.paypal.me/HR5454">Click here to pay!
                        </a></u>
                    </div>
                    <br>
                    <br>
                    <p>Attach Payment Screenshot (Optional)</p>
                    <input type="file" wire:model="evidence"
                        style="width: 100%;height: 30px;border-radius: 0px;padding-left: 0px;border-color:#224794;"
                        placeholder="Evidence">
                    @error('evidence')
                    <span style="color: red">{{ $message }}</span>
                    @enderror
                    @endif
                    <br>
                    <br>
                </div>
                @endif
                                        <div class="happyforms-form__part happyforms-part happyforms-part--submit"
                                            style="text-align:center;">
                                            @if($type == 'stripe')
                                            <a href="{{ url('/pay-now-with-stripe?type=5&price=') }}{{ $fee }}"
                                                style="text-align:cener;padding: 15px 30px;1px solid transparent;ont-size: var(--happyforms-submit-button-font-size);color:white;background:#02427d;width:100%;border-radius: 47px;"
                                                type="submit"
                                                class="happyforms-submit happyforms-button--submit devsite">Pay with
                                                stripe ({{$user->type == 'International' ? '$' : '£'}}{{$fee}})
                                            </a>
                                            @endif
                                            @if($type == 'other' || $type == 'paypal' && !session('message'))
                                            <button wire:click="manuaReq('Anual Fee')"
                                                style="text-align:cener;color:green;padding: 15px 30px;1px solid transparent;ont-size: var(--happyforms-submit-button-font-size);color:white;background:#02427d;width:100%;border-radius: 47px;"
                                                class="happyforms-submit happyforms-button--submit devsite">
                                                Yes, I would like to proceed
                                                {{-- Pay Now
                                             ({{$user->type == 'International' ? '$' : '£'}}{{$fee}}) --}}
                                            </button>
                                            @endif
                                        </div>
                                        @endif
                                    </div>
                                </div>


                            </div>
                        </div>
                    </div>

                    <style type="text/css">
                        .fusion-body .fusion-builder-column-10 {
                            width: 60% !important;
                            margin-top: 20px;
                            margin-bottom: 20px;
                        }

                        .fusion-builder-column-10>.fusion-column-wrapper {
                            padding-top: 0px !important;
                            padding-right: 0px !important;
                            margin-right: 3.2%;
                            padding-bottom: 0px !important;
                            padding-left: 0px !important;
                            margin-left: 3.2%;
                        }

                        @media only screen and (max-width:1024px) {
                            .fusion-body .fusion-builder-column-10 {
                                width: 60% !important;
                                order: 0;
                            }

                            .fusion-builder-column-10>.fusion-column-wrapper {
                                margin-right: 3.2%;
                                margin-left: 3.2%;
                            }
                        }

                        @media only screen and (max-width:640px) {
                            .fusion-body .fusion-builder-column-10 {
                                width: 100% !important;
                                order: 0;
                            }

                            .fusion-builder-column-10>.fusion-column-wrapper {
                                margin-right: 1.92%;
                                margin-left: 1.92%;
                            }
                        }

                    </style>

                    <style type="text/css">
                        .fusion-body .fusion-builder-column-11 {
                            width: 20% !important;
                            margin-top: 20px;
                            margin-bottom: 20px;
                        }

                        .fusion-builder-column-11>.fusion-column-wrapper {
                            padding-top: 0px !important;
                            padding-right: 0px !important;
                            margin-right: 9.6%;
                            padding-bottom: 0px !important;
                            padding-left: 0px !important;
                            margin-left: 9.6%;
                        }

                        @media only screen and (max-width:1024px) {
                            .fusion-body .fusion-builder-column-11 {
                                width: 20% !important;
                                order: 0;
                            }

                            .fusion-builder-column-11>.fusion-column-wrapper {
                                margin-right: 9.6%;
                                margin-left: 9.6%;
                            }
                        }

                        @media only screen and (max-width:640px) {
                            .fusion-body .fusion-builder-column-11 {
                                width: 100% !important;
                                order: 0;
                            }

                            .fusion-builder-column-11>.fusion-column-wrapper {
                                margin-right: 1.92%;
                                margin-left: 1.92%;
                            }
                        }

                    </style>
                </div>
                <style type="text/css">
                    .fusion-body .fusion-flex-container.fusion-builder-row-5 {
                        padding-top: 0px;
                        margin-top: 0px;
                        padding-right: 32px;
                        padding-bottom: 0px;
                        margin-bottom: 0px;
                        padding-left: 32px;
                    }

                </style>
            </div>
        </div>
    </div>
</section>
